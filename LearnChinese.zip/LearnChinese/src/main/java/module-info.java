module ap.learnchinese {
    requires javafx.controls;
    requires javafx.media;
    requires org.hibernate.orm.core; 
 requires java.naming;
 requires java.persistence;
 requires java.sql;
 opens ap.learnchinese;
    exports ap.learnchinese;
}
