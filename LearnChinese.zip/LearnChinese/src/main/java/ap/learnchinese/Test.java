/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ap.learnchinese;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Test implements java.io.Serializable{

    @Id
    @Column(name = "gameid")
    private int id;
    
    @ManyToOne
    @JoinColumn(name = "userid")
    private User userid;
        
    @Column(name="gamelevel")
    private String gamelevel;
    
    @Column(name ="score")
    private int score;
    
      public Test(){       
    }
    
          public Test(int id,User userid,String gamelevel,int score){
        
       this.id=id; 
       this.userid=userid;
       this.gamelevel=gamelevel;
       this.score=score;  
    }

    public User getUserid() {
        return userid;
    }

    public void setUserid(User userid) {
        this.userid = userid;
    }

    public int getId(){
        return id;
    }

    public void setId(int id){
     this.id=id;   
        
    }
    
    public String getgameLevel(){
        return gamelevel;
    }
    
    public void setgameLevel(String gamelevel){
        this.gamelevel=gamelevel;
    }
    
    public int getScore(){
        return score;
    }
    
    public void setScore(int score){
       this.score=score; 
        
    }
    
   
  
}