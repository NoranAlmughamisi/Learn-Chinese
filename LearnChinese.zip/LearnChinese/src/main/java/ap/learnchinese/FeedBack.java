/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ap.learnchinese;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "feedback")
public class FeedBack implements java.io.Serializable {

    @Id
    @Column(name = "feedbackid")
    private int feedbackid;

    @ManyToOne
    @JoinColumn(name = "userid")
    private User userid;

    @Column(name = "score")
    private int score;

    @Column(name = "comments", length = 255)
    private String comments;

    @Column(name = "date")
    private LocalDate date;

    // Constructors, getters, setters, and other methods

    public FeedBack() {
    }

    public FeedBack(User user, int score, String comments, LocalDate date) {
        this.userid = user;
        this.score = score;
        this.comments = comments;
        this.date = date;
    }

    public int getFeedbackid() {
        return feedbackid;
    }

    public void setFeedbackid(int feedbackid) {
        this.feedbackid = feedbackid;
    }

    public User getUserid() {
        return userid;
    }

    public void setUserid(User userid) {
        this.userid = userid;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }
    

}
