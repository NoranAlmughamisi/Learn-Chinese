package ap.learnchinese;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.shape.StrokeLineJoin;
import javafx.scene.shape.StrokeType;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;



/**
 * JavaFX App
 */
public class App extends Application {
 private static final Image STAR_EMPTY = new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//rate//star_empty.png");
    private static final Image STAR_FILLED = new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//rate//star_fill.png");
    private static final int NUM_STARS = 5;
    private static final double STAR_SIZE = 60; // Adjust the star size as needed
    private Button[] starButtons;
    private ImageView[] starImageViews;
    private int score=0;
    private int point = 0;
    private User newUser;

    @Override
    public void start(Stage stage) {
        
       //-----------**********Front Page****************-----------------------
       AnchorPane anchorPane_Fs = new AnchorPane();
        anchorPane_Fs.setPrefHeight(400.0);
        anchorPane_Fs.setPrefWidth(800.0);
        ImageView backgroundImageView_Fs = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
        backgroundImageView_Fs.setFitWidth(800.0);
        backgroundImageView_Fs.setPreserveRatio(true);

        Button loginButton = new Button("Login");
        loginButton.setCache(true);
        loginButton.setLayoutX(194.0);
        loginButton.setLayoutY(299.0);
        loginButton.setMnemonicParsing(false);
        loginButton.setPrefHeight(43.0);
        loginButton.setPrefWidth(185.0);
        loginButton.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        loginButton.setTextAlignment(TextAlignment.CENTER);
        loginButton.setTextFill(Color.WHITE);
        loginButton.setFont(new Font(20.0));

        DropShadow dropShadow = new DropShadow();
        dropShadow.setColor(Color.rgb(242, 239, 239));
        loginButton.setEffect(dropShadow);

        Button signUpButton = new Button("Sign up");
        signUpButton.setCache(true);
        signUpButton.setLayoutX(408.0);
        signUpButton.setLayoutY(298.0);
        signUpButton.setMnemonicParsing(false);
        signUpButton.setPrefHeight(43.0);
        signUpButton.setPrefWidth(185.0);
        signUpButton.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        signUpButton.setTextAlignment(TextAlignment.CENTER);
        signUpButton.setTextFill(Color.WHITE);
        signUpButton.setFont(new Font(21.0));
        signUpButton.setEffect(dropShadow);

        Rectangle rectangle_Fs = new Rectangle(212.0, 69.0, 376.0, 202.0);
        rectangle_Fs.setArcHeight(5.0);
        rectangle_Fs.setArcWidth(5.0);
        rectangle_Fs.setFill(Color.web("#ed7a60a8"));
        rectangle_Fs.setStroke(Color.web("#f3d5c7"));
        rectangle_Fs.setStrokeLineCap(StrokeLineCap.ROUND);
        rectangle_Fs.setStrokeLineJoin(StrokeLineJoin.ROUND);
        rectangle_Fs.setStrokeType(StrokeType.OUTSIDE);
        rectangle_Fs.setStrokeWidth(2.0);

        ImageView lanternImageView = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images/s0/lamb.png");
        lanternImageView.setLayoutX(517.0);
        lanternImageView.setLayoutY(67.0);
        lanternImageView.setFitWidth(71.0);
        lanternImageView.setFitHeight(65.0);
        lanternImageView.setPickOnBounds(true);
        lanternImageView.setPreserveRatio(true);

        ImageView chinese1ImageView = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images/s0/boy.png");
        chinese1ImageView.setLayoutX(210.0);
        chinese1ImageView.setLayoutY(213.0);
        chinese1ImageView.setFitWidth(90.0);
        chinese1ImageView.setFitHeight(60.0);
        chinese1ImageView.setPickOnBounds(true);
        chinese1ImageView.setPreserveRatio(true);

        ImageView chinese2ImageView = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images/s0/girl.png");
        chinese2ImageView.setLayoutX(270.0);
        chinese2ImageView.setLayoutY(209.0);
        chinese2ImageView.setFitWidth(71.0);
        chinese2ImageView.setFitHeight(64.0);
        chinese2ImageView.setPickOnBounds(true);
        chinese2ImageView.setPreserveRatio(true);

        Text learnChineseText_Fs = new Text("LearnChinese");
        learnChineseText_Fs.setFill(Color.WHITE);
        learnChineseText_Fs.setFont(Font.font("Imprint MT Shadow", 45.0));
        learnChineseText_Fs.setLayoutX(210.0);
        learnChineseText_Fs.setLayoutY(174.0);
        learnChineseText_Fs.setTextAlignment(TextAlignment.CENTER);
        learnChineseText_Fs.setWrappingWidth(308.69140625);

        Text learnChineseText2_Fs = new Text("学习中文");
        learnChineseText2_Fs.setFill(Color.WHITE);
        learnChineseText2_Fs.setFont(Font.font("Imprint MT Shadow", 51.0));
        learnChineseText2_Fs.setLayoutX(348.0);
        learnChineseText2_Fs.setLayoutY(233.0);
        learnChineseText2_Fs.setTextAlignment(TextAlignment.CENTER);
        learnChineseText2_Fs.setWrappingWidth(233.19140625);

        anchorPane_Fs.getChildren().addAll(
                backgroundImageView_Fs, loginButton, signUpButton, rectangle_Fs,
                lanternImageView, chinese1ImageView, chinese2ImageView,
                learnChineseText_Fs, learnChineseText2_Fs
        );

        Scene scene0 = new Scene(anchorPane_Fs, 800, 400);
        stage.setScene(scene0);
        stage.show();
    

     // ------------*************signup page***************--------------------------- 
        ImageView b0 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
        b0.setFitWidth(800);
        b0.setPreserveRatio(true);

        Text t0 = new Text("Learn Chinese");
        t0.setFill(Color.WHITE); // Change color to white
        t0.setFont(Font.font("Times new roman", FontWeight.BOLD,FontPosture.ITALIC, 60)); // Change font
        t0.setStyle("-fx-stroke: #992725;"+"-fx-stroke-width: 1;");

        Text usern0 = new Text("UserName:");
        usern0.setFill(Color.WHITE); // Change color to white
        usern0.setFont(Font.font("Helvetica", FontWeight.BOLD, 25)); // Change font
        usern0.setStyle("-fx-stroke: #992725;");
        Text email = new Text("Email:");
        email.setFill(Color.WHITE); // Change color to white
        email.setFont(Font.font("Helvetica", FontWeight.BOLD, 25)); // Change font
        email.setStyle("-fx-stroke: #992725;");
        Text pass0 = new Text("Password:");
        pass0.setFill(Color.WHITE); // Change color to white
        pass0.setFont(Font.font("Helvetica", FontWeight.BOLD, 25)); // Change font
        pass0.setStyle("-fx-stroke:#992725;");
        TextField usertf0 = new TextField();
        TextField emailtf = new TextField();
        PasswordField passtf0 = new PasswordField();
        usertf0.setPromptText("Enter Your User Name");
        emailtf.setPromptText("Enter Youe email");
        passtf0.setPromptText("Enter Your password");
        usertf0.setPrefWidth(220);
        emailtf.setPrefWidth(220);
        passtf0.setPrefWidth(220);
        usertf0.setPrefHeight(32);
        emailtf.setPrefHeight(32);
        passtf0.setPrefHeight(32);
        //Label for date of birth and date picker to choose date
        Text dobLabel = new Text("Date of birth");
        dobLabel.setFill(Color.WHITE); // Change color to white
        dobLabel.setFont(Font.font("Helvetica", FontWeight.BOLD, 25)); // Change font
        dobLabel.setStyle("-fx-stroke:#992725;");
        DatePicker datePicker = new DatePicker();
        datePicker.setPrefWidth(220);
        datePicker.setPrefHeight(32);
        //Label for gender and group of radioButtons
        Text genderLabel = new Text("gender");
        genderLabel.setFill(Color.WHITE); // Change color to white
        genderLabel.setFont(Font.font("Helvetica", FontWeight.BOLD, 25)); // Change font
        genderLabel.setStyle("-fx-stroke:#992725;");
        ToggleGroup groupGender = new ToggleGroup();
        RadioButton maleRadio = new RadioButton("male");
        maleRadio.setToggleGroup(groupGender);
        RadioButton femaleRadio = new RadioButton("female");
        femaleRadio.setToggleGroup(groupGender);
        maleRadio.setStyle("-fx-font-family: 'Helvetica'; -fx-font-weight: bold; "
                + "-fx-font-size: 16; -fx-text-fill: gray;");
        femaleRadio.setStyle("-fx-font-family: 'Helvetica'; -fx-font-weight: bold; "
                + "-fx-font-size: 16; -fx-text-fill: gray;");
    //---------------------Buttons-----------------------
        HBox hbox=new HBox(10);
        hbox.setPadding(new Insets(10,10,50,10));
        hbox.setAlignment(Pos.BOTTOM_CENTER);
       // hbox.setTranslateY(-15);
        Button submit = new Button("SignUp");
        Button clear = new Button("Clear");
        submit.setStyle(
            "-fx-background-color: #dc836f;-fx-text-fill: white; -fx-font-size: 16px; " + 
            "-fx-min-width: 120px;-fx-min-height: 40px; -fx-max-width: 120px; " + 
            "-fx-max-height: 40px; -fx-background-radius: 20px;" );
        clear.setStyle(
          "-fx-background-color: #dc836f;-fx-text-fill: white; -fx-font-size: 16px; " + 
            "-fx-min-width: 120px;-fx-min-height: 40px; -fx-max-width: 120px; " + 
            "-fx-max-height: 40px; -fx-background-radius: 20px;" );
        hbox.getChildren().addAll(submit,clear);             
       clear.setOnAction(e -> {
            emailtf.clear();
            passtf0.clear();
            usertf0.clear();
            groupGender.selectToggle(null); // Clear radio button selection
            datePicker.setValue(null);
        });
        GridPane pane = new GridPane();
        pane.setPadding(new Insets(40, 10, 10, 10));
        pane.setHgap(10);
        pane.setVgap(10);
        pane.setAlignment(Pos.CENTER);
        pane.add(usern0,0,0);
        pane.add(usertf0,1,0);
        pane.add(dobLabel,0,1);
        pane.add(datePicker,1,1);
        pane.add(genderLabel,0,2);
        pane.add(maleRadio,1,2);
        pane.add(femaleRadio,2,2);
        pane.add(email,0,3);
        pane.add(emailtf,1,3);
        pane.add(pass0,0,4);
        pane.add(passtf0,1,4);
        //----------------------------------------
        Button btHome = new Button();
        btHome.setPrefHeight(53.0);
        btHome.setPrefWidth(52.0);
        btHome.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView Homeicon = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        Homeicon.setFitHeight(36.0);
        Homeicon.setFitWidth(32.0);
        Homeicon.setPreserveRatio(true);
        btHome.setGraphic(Homeicon);
        HBox top0=new HBox(20,btHome,t0);
          top0.setAlignment( Pos.TOP_CENTER);
          top0.setTranslateY(40);

        //-----------------------------------------
        BorderPane borderPane = new BorderPane();
        borderPane.setTop(top0);
        borderPane.setBottom(hbox);
        borderPane.setCenter(pane);
        //----------------------------------
        StackPane sign=new StackPane(b0,borderPane);
        Scene signup = new Scene(sign, 800, 400);
        signUpButton.setOnAction(e -> {
            stage.setScene(signup); 
            stage.show();
        });

          submit.setOnAction(e -> {
                      try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        Transaction tx = session.beginTransaction();

        // Create a new user
         newUser = new User();
        newUser.setUsername(usertf0.getText());
        newUser.setEmail(emailtf.getText());
        newUser.setPassword(passtf0.getText());

        // Convert LocalDate to java.sql.Date for the 'dob' field
        Date dob = Date.valueOf(datePicker.getValue());
        newUser.setDob(dob);

        // Get selected gender from radio buttons
        String gender = maleRadio.isSelected() ? "male" : (femaleRadio.isSelected() ? "female" : null);
        newUser.setGender(gender);

        // Save the user to the database
        session.save(newUser);

        tx.commit();
 
        // Display success message
        Rectangle successRect = new Rectangle(400, 50);
        successRect.setFill(Color.web("#992725", 0.5));

        Text successText = new Text("User registration successful");
        successText.setFill(Color.WHITE);
        successText.setFont(Font.font("Helvetica", FontWeight.BOLD, 20));

        StackPane successPane = new StackPane(successRect, successText);
        successPane.setAlignment(Pos.CENTER);

        BorderPane successBorderPane = new BorderPane();
        successBorderPane.setCenter(successPane);

        StackPane finalPane = new StackPane(sign, successBorderPane);

        Scene successScene = new Scene(finalPane, 800, 400);
        stage.setScene(successScene);
        stage.show();
        // Set up a timeline to remove the success message after a certain duration
        Duration displayDuration = Duration.seconds(2);
        Timeline timeline = new Timeline(new KeyFrame(displayDuration, event -> {
            stage.setScene(signup);
            stage.show();
        }));
        timeline.play();
  } catch (Exception ex) {
        ex.printStackTrace();
        // Handle exceptions
    } 
});  
        btHome.setOnAction(e->{
         stage.setScene(scene0);   
         stage.show(); 
        });
    //---------------------*******login******------------------------------
        ImageView b1 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
        b1.setFitWidth(800);
        b1.setPreserveRatio(true);
        Text t1 = new Text("Learn Chinese");
        t1.setFill(Color.WHITE); // Change color to white
        t1.setFont(Font.font("Times new roman", FontWeight.BOLD,FontPosture.ITALIC, 60)); // Change font
        t1.setStyle("-fx-stroke: #992725;"+"-fx-stroke-width: 1;");
        
        Button blog = new Button("LogIn");
        blog.setStyle(
            "-fx-background-color: #dc836f;-fx-text-fill: white; -fx-font-size: 16px; " + 
            "-fx-min-width: 120px;-fx-min-height: 40px; -fx-max-width: 120px; " + 
            "-fx-max-height: 40px; -fx-background-radius: 20px;" );

          VBox bvlog=new VBox(10,blog);
          bvlog.setAlignment( Pos.BOTTOM_CENTER);
          bvlog.setPadding(new Insets(10,10,50,10));
          
        Text usern1 = new Text("UserName:");
        usern1.setFill(Color.WHITE); // Change color to white
        usern1.setFont(Font.font("Helvetica", FontWeight.BOLD, 25)); // Change font
        usern1.setStyle("-fx-stroke: #992725;");
        Text pass1 = new Text("Password:");
        pass1.setFill(Color.WHITE); // Change color to white
        pass1.setFont(Font.font("Helvetica", FontWeight.BOLD, 25)); // Change font
        pass1.setStyle("-fx-stroke:#992725;");
        TextField usertf1 = new TextField();
        PasswordField passtf1 = new PasswordField();
        usertf1.setPromptText("Enter Your User Name");
        passtf1.setPromptText("Enter Your password");
        usertf1.setPrefWidth(220);
        passtf1.setPrefWidth(220);
        usertf1.setPrefHeight(32);
        passtf1.setPrefHeight(32);
        GridPane pane1 = new GridPane();
        pane1.setHgap(10);
        pane1.setVgap(10);
        pane1.setAlignment(Pos.CENTER);
        pane1.add(usern1,0,0);
        pane1.add(usertf1,1,0);
        pane1.add(pass1,0,1);
        pane1.add(passtf1,1,1);
        
        Button btHome1 = new Button();
        btHome1.setPrefHeight(53.0);
        btHome1.setPrefWidth(52.0);
        btHome1.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView Homeicon1 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        Homeicon1.setFitHeight(36.0);
        Homeicon1.setFitWidth(32.0);
        Homeicon1.setPreserveRatio(true);
        btHome1.setGraphic(Homeicon1);

        HBox top1=new HBox(20,btHome1,t1);
         top1.setPadding(new Insets(100,10,10,10));
         top1.setAlignment( Pos.TOP_CENTER);
         
        BorderPane borderPane1 = new BorderPane();
      //  BorderPane.setAlignment(top1, Pos.TOP_CENTER);
        borderPane1.setTop(top1);
        borderPane1.setBottom(bvlog);
       // BorderPane.setAlignment(blog, Pos.BOTTOM_CENTER);
        borderPane1.setCenter(pane1);
      
        StackPane log=new StackPane(b1,borderPane1);
        
        Scene login = new Scene(log, 800, 400);
        loginButton.setOnAction(e -> {
            stage.setScene(login); // Set the scene to the login scene
        });
        btHome1.setOnAction(e->{
         stage.setScene(scene0);
         stage.show(); 
        });
        
    //-------------------*******Choose from many options********----------------
        AnchorPane anchorPane_S2 = new AnchorPane();
        anchorPane_S2.setPrefHeight(400.0);
        anchorPane_S2.setPrefWidth(800.0);

        ImageView backgroundImageView_S2 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
        backgroundImageView_S2.setFitWidth(800.0);
        backgroundImageView_S2.setPreserveRatio(true);

        Text learnChineseText_S2 = new Text("LearnChinese");
        learnChineseText_S2.setFill(Color.WHITE);
        learnChineseText_S2.setFont(Font.font("Imprint MT Shadow", 51.0));
        learnChineseText_S2.setLayoutX(238.0);
        learnChineseText_S2.setLayoutY(72.0);
        learnChineseText_S2.setTextAlignment(TextAlignment.CENTER);
        learnChineseText_S2.setWrappingWidth(324.69140625);

        DropShadow dropShadow1 = new DropShadow();
        dropShadow1.setColor(Color.rgb(242, 239, 239));

        Button learnButton_S2 = new Button("Learn");
        learnButton_S2.setCache(true);
        learnButton_S2.setLayoutX(316.0);
        learnButton_S2.setLayoutY(95.0);
        learnButton_S2.setMnemonicParsing(false);
        learnButton_S2.setPrefHeight(43.0);
        learnButton_S2.setPrefWidth(185.0);
        learnButton_S2.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        learnButton_S2.setTextAlignment(TextAlignment.CENTER);
        learnButton_S2.setTextFill(Color.WHITE);
        learnButton_S2.setFont(new Font(21.0));
        learnButton_S2.setEffect(dropShadow);

        Button testButton_S2 = new Button("Test");
        testButton_S2.setCache(true);
        testButton_S2.setLayoutX(316.0);
        testButton_S2.setLayoutY(157.0);
        testButton_S2.setMnemonicParsing(false);
        testButton_S2.setPrefHeight(43.0);
        testButton_S2.setPrefWidth(185.0);
        testButton_S2.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        testButton_S2.setTextAlignment(TextAlignment.CENTER);
        testButton_S2.setTextFill(Color.WHITE);
        testButton_S2.setFont(new Font(20.0));
        testButton_S2.setEffect(dropShadow);

        Button ratingButton_S2 = new Button("Rating");
        ratingButton_S2.setCache(true);
        ratingButton_S2.setLayoutX(316.0);
        ratingButton_S2.setLayoutY(218.0);
        ratingButton_S2.setMnemonicParsing(false);
        ratingButton_S2.setPrefHeight(43.0);
        ratingButton_S2.setPrefWidth(185.0);
        ratingButton_S2.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        ratingButton_S2.setTextAlignment(TextAlignment.CENTER);
        ratingButton_S2.setTextFill(Color.WHITE);
        ratingButton_S2.setFont(new Font(21.0));
        ratingButton_S2.setEffect(dropShadow);
        
        Button LogOutButton_S2 = new Button("Log Out");
        LogOutButton_S2.setCache(true);
        LogOutButton_S2.setLayoutX(316.0);
        LogOutButton_S2.setLayoutY(285.0);
        LogOutButton_S2.setMnemonicParsing(false);
        LogOutButton_S2.setPrefHeight(43.0);
        LogOutButton_S2.setPrefWidth(185.0);
        LogOutButton_S2.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        LogOutButton_S2.setTextAlignment(TextAlignment.CENTER);
        LogOutButton_S2.setTextFill(Color.WHITE);
        LogOutButton_S2.setFont(new Font(21.0));
        LogOutButton_S2.setEffect(dropShadow);

        anchorPane_S2.getChildren().addAll(
                backgroundImageView_S2, learnChineseText_S2,
                learnButton_S2, testButton_S2, ratingButton_S2,
                LogOutButton_S2
        );
        
        Scene sceneMany = new Scene(anchorPane_S2, 800, 400);
        blog.setOnAction(e->{
    String enteredUsername = usertf1.getText();
    String enteredPassword = passtf1.getText();

    Session session = null;
    Transaction transaction = null;

    try {
        session = HibernateUtil.getSessionFactory().openSession();
        transaction = session.beginTransaction();

        Query<User> query = session.createQuery("FROM User WHERE username = :username AND password = :password", User.class);
        query.setParameter("username", enteredUsername);
        query.setParameter("password", enteredPassword);

        List<User> result = query.getResultList();

        if (!result.isEmpty()) {
            // Successful login
            stage.setScene(sceneMany);
            System.out.println("Login successful!");
        } else {
            // Failed login
            // You may want to display an error message or take other actions
            System.out.println("Invalid username or password");
        }

        transaction.commit();
    } catch (Exception ex) {
        if (transaction != null) {
            transaction.rollback();
        }
        ex.printStackTrace();
        // Handle exceptions
    } finally {
        if (session != null) {
            session.close();
        }
    }
        });     
        
        //-------------------**Learn Scetions***-------------------
          //-------------word hi -----
        AnchorPane roothi = new AnchorPane();
        ImageView b2 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
        b2.setFitWidth(800);
        b2.setPreserveRatio(true);
        roothi.getChildren().add(b2);
        Text t2 = new Text("Learn Chinese");
        t2.setFill(Color.WHITE); // Change color to white
        t2.setFont(Font.font("Times new roman", FontWeight.BOLD,FontPosture.ITALIC, 38)); // Change font
        t2.setStyle("-fx-stroke: #992725;"+"-fx-stroke-width: 1;");
        t2.setLayoutX(120);
        t2.setLayoutY(59);
        t2.setTextAlignment(TextAlignment.CENTER);
        roothi.getChildren().add(t2);
        
        Button nextButton = new Button("Next");
        nextButton.setLayoutX(558);
        nextButton.setLayoutY(347);
        nextButton.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButton.setTextFill(Color.WHITE);
        nextButton.setFont(Font.font(18));
        roothi.getChildren().add(nextButton);
        
        Rectangle rectangle = new Rectangle(233, 78, 320, 215);
        rectangle.setArcHeight(5);
        rectangle.setArcWidth(5);
        rectangle.setFill(Color.web("#db847092"));
        rectangle.setStroke(Color.WHITE);
        rectangle.setStrokeLineCap(StrokeLineCap.ROUND);
        rectangle.setStrokeLineJoin(StrokeLineJoin.ROUND);
        rectangle.setStrokeType(StrokeType.OUTSIDE);
        rectangle.setStrokeWidth(2);
        rectangle.setStyle("-fx-stroke-dash-array: 10;");
        roothi.getChildren().add(rectangle);
        Button audio0bt = new Button();
        audio0bt.setLayoutX(475);
        audio0bt.setLayoutY(174);
        audio0bt.setPrefHeight(53);
        audio0bt.setPrefWidth(52);
        ImageView audio0 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//audio.png");
        audio0.setFitHeight(55);
        audio0.setFitWidth(50);
        audio0.setLayoutX(476);
        audio0.setLayoutY(176);
        audio0bt.setGraphic(audio0);
        audio0bt.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        roothi.getChildren().add(audio0bt);
        ImageView hi = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//hi/hi.png");
        hi.setFitHeight(150);
        hi.setFitWidth(200);
        hi.setLayoutX(250);
        hi.setLayoutY(111);
        roothi.getChildren().add(hi);
        Text l1 = new Text("Hello");
        l1.setFill(Color.web("#ffffff"));
        l1.setLayoutX(295);
        l1.setLayoutY(119);
        l1.setFont(Font.font("Times new roman", 24));
        roothi.getChildren().add(l1);
        Text ch0 = new Text("你好");
        ch0.setFill(Color.web("#ffffff"));
        ch0.setLayoutX(480);
        ch0.setLayoutY(121);
        ch0.setFont(Font.font("Times new roman",26));
        roothi.getChildren().add(ch0);

        Button btHomehi = new Button();
        btHomehi.setLayoutX(50.0);
        btHomehi.setLayoutY(21.0);
        btHomehi.setMnemonicParsing(false);
        btHomehi.setPrefHeight(53.0);
        btHomehi.setPrefWidth(52.0);
        btHomehi.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView Homeiconhi = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        Homeiconhi.setFitHeight(36.0);
        Homeiconhi.setFitWidth(32.0);
        Homeiconhi.setPreserveRatio(true);
        btHomehi.setGraphic(Homeiconhi);
        roothi.getChildren().add(btHomehi);
        
         btHomehi.setOnAction(e->{
         stage.setScene(sceneMany);
        stage.show();
         });
        
        Media media0 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//hi/hi.mp3");  
        MediaPlayer mediaPlayer0 = new MediaPlayer(media0); 
        audio0bt.setOnAction(e ->{  
        mediaPlayer0.stop(); // Stop the media if it's already playing
        mediaPlayer0.play(); // Start playing the media
         }) ;

        Scene hiScene = new Scene(roothi, 800, 400);
        learnButton_S2.setOnAction(e->{
        stage.setScene(hiScene);
        stage.show();
        
        });
        
        //-------------word yes-----
        AnchorPane root1 = new AnchorPane();
        ImageView b3 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
        b3.setFitWidth(800);
        b3.setPreserveRatio(true);
        root1.getChildren().add(b3);
        
        Text t3 = new Text("Learn Chinese");
        t3.setFill(Color.WHITE); // Change color to white
        t3.setFont(Font.font("Times new roman", FontWeight.BOLD,FontPosture.ITALIC, 38)); // Change font
        t3.setStyle("-fx-stroke: #992725;"+"-fx-stroke-width: 1;");
        t3.setLayoutX(120);
        t3.setLayoutY(59);
        t3.setTextAlignment(TextAlignment.CENTER);
        root1.getChildren().add(t3);
        
        Button nextButton0 = new Button("Next");
        nextButton0.setLayoutX(558);
        nextButton0.setLayoutY(347);
        nextButton0.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButton0.setTextFill(Color.WHITE);
        nextButton0.setFont(Font.font(18));
        root1.getChildren().add(nextButton0);
        Button backButton = new Button("Back");
        backButton.setLayoutX(178);
        backButton.setLayoutY(347);
        backButton.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        backButton.setTextFill(Color.WHITE);
        backButton.setFont(Font.font(18));
        root1.getChildren().add(backButton);
        backButton.setOnAction(e->{
          stage.setScene(hiScene);
          stage.show();
        });
        Rectangle rectangle0 = new Rectangle(233, 78, 320, 215);
        rectangle0.setArcHeight(5);
        rectangle0.setArcWidth(5);
        rectangle0.setFill(Color.web("#db847092"));
        rectangle0.setStroke(Color.WHITE);
        rectangle0.setStrokeLineCap(StrokeLineCap.ROUND);
        rectangle0.setStrokeLineJoin(StrokeLineJoin.ROUND);
        rectangle0.setStrokeType(StrokeType.OUTSIDE);
        rectangle0.setStrokeWidth(2);
        rectangle0.setStyle("-fx-stroke-dash-array: 10;");
        root1.getChildren().add(rectangle0);
        
        Button audio1bt = new Button();
        audio1bt.setLayoutX(475);
        audio1bt.setLayoutY(174);
        audio1bt.setPrefHeight(53);
        audio1bt.setPrefWidth(52);
        ImageView audio1 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//audio.png");
        audio1.setFitHeight(55);
        audio1.setFitWidth(50);
        audio1.setLayoutX(476);
        audio1.setLayoutY(176);
        audio1bt.setGraphic(audio1);
        audio1bt.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        root1.getChildren().add(audio1bt);
        
        ImageView yes = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//yes/yes.png");
        yes.setFitHeight(95);
        yes.setFitWidth(97);
        yes.setLayoutX(278);
        yes.setLayoutY(158);
        root1.getChildren().add(yes);
       
        Text yesword = new Text("Yes");
        yesword.setFill(Color.web("#ffffff"));
        yesword.setLayoutX(295);
        yesword.setLayoutY(119);
        yesword.setFont(Font.font("Times new roman", 24));
        root1.getChildren().add(yesword);       
        Text ch1 = new Text("是的");
        ch1.setFill(Color.web("#ffffff"));
        ch1.setLayoutX(480);
        ch1.setLayoutY(121);
        ch1.setFont(Font.font("Times new roman",26));
        root1.getChildren().add(ch1);
        
        Button btHomeyes = new Button();
        btHomeyes.setLayoutX(50.0);
        btHomeyes.setLayoutY(21.0);
        btHomeyes.setMnemonicParsing(false);
        btHomeyes.setPrefHeight(53.0);
        btHomeyes.setPrefWidth(52.0);
        btHomeyes.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView Homeiconyes = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        Homeiconyes.setFitHeight(36.0);
        Homeiconyes.setFitWidth(32.0);
        Homeiconyes.setPreserveRatio(true);
        btHomeyes.setGraphic(Homeiconyes);
        root1.getChildren().add(btHomeyes);
         
         btHomeyes.setOnAction(e->{
         stage.setScene(sceneMany);
        stage.show();
         });
        
        Media media1 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images/Yes/yes.mp3");  
        MediaPlayer mediaPlayer1 = new MediaPlayer(media1); 
        audio1bt.setOnAction(e ->{  
        mediaPlayer1.stop(); // Stop the media if it's already playing
        mediaPlayer1.play(); // Start playing the media
         }) ;
        
        Scene syes = new Scene(root1, 800, 400);
        nextButton.setOnAction(e->{
        stage.setScene(syes);
        stage.show();});
        
        //-------------((((((((((((word no))))))))))))))))-----
        AnchorPane root2 = new AnchorPane();
        ImageView b4 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
        b4.setFitWidth(800);
        b4.setPreserveRatio(true);
        root2.getChildren().add(b4);
        Text t4 = new Text("Learn Chinese");
        t4.setFill(Color.WHITE); // Change color to white
        t4.setFont(Font.font("Times new roman", FontWeight.BOLD,FontPosture.ITALIC, 38)); // Change font
        t4.setStyle("-fx-stroke: #992725;"+"-fx-stroke-width: 1;");
        t4.setLayoutX(120);
        t4.setLayoutY(59);
        t4.setTextAlignment(TextAlignment.CENTER);
        root2.getChildren().add(t4);
        
        Button nextButton1 = new Button("Next");
        nextButton1.setLayoutX(558);
        nextButton1.setLayoutY(347);
        nextButton1.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButton1.setTextFill(Color.WHITE);
        nextButton1.setFont(Font.font(18));
        root2.getChildren().add(nextButton1);
        Button backButton1 = new Button("Back");
        backButton1.setLayoutX(178);
        backButton1.setLayoutY(347);
        backButton1.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        backButton1.setTextFill(Color.WHITE);
        backButton1.setFont(Font.font(18));
        root2.getChildren().add(backButton1);
        backButton1.setOnAction(e->{
          stage.setScene(syes);
          stage.show();
        });
        Rectangle rectangle1 = new Rectangle(233, 78, 320, 215);
        rectangle1.setArcHeight(5);
        rectangle1.setArcWidth(5);
        rectangle1.setFill(Color.web("#db847092"));
        rectangle1.setStroke(Color.WHITE);
        rectangle1.setStrokeLineCap(StrokeLineCap.ROUND);
        rectangle1.setStrokeLineJoin(StrokeLineJoin.ROUND);
        rectangle1.setStrokeType(StrokeType.OUTSIDE);
        rectangle1.setStrokeWidth(2);
        rectangle1.setStyle("-fx-stroke-dash-array: 10;");
        root2.getChildren().add(rectangle1);
        
        Button audio2bt = new Button();
        audio2bt.setLayoutX(475);
        audio2bt.setLayoutY(174);
        audio2bt.setPrefHeight(53);
        audio2bt.setPrefWidth(52);
        ImageView audio2 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//audio.png");
        audio2.setFitHeight(55);
        audio2.setFitWidth(50);
        audio2.setLayoutX(476);
        audio2.setLayoutY(176);
        audio2bt.setGraphic(audio2);
        audio2bt.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        root2.getChildren().add(audio2bt);
        
        ImageView no = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//no/no.png");
        no.setFitHeight(95);
        no.setFitWidth(97);
        no.setLayoutX(278);
        no.setLayoutY(158);
        root2.getChildren().add(no);
       
        Text noword = new Text("No");
        noword.setFill(Color.web("#ffffff"));
        noword.setLayoutX(295);
        noword.setLayoutY(119);
        noword.setFont(Font.font("Times new roman", 24));
        root2.getChildren().add(noword);       
        Text ch2 = new Text("不");
        ch2.setFill(Color.web("#ffffff"));
        ch2.setLayoutX(480);
        ch2.setLayoutY(121);
        ch2.setFont(Font.font("Times new roman",26));
        root2.getChildren().add(ch2);
        
        Button btHomeNo = new Button();
        btHomeNo.setLayoutX(50.0);
        btHomeNo.setLayoutY(21.0);
        btHomeNo.setMnemonicParsing(false);
        btHomeNo.setPrefHeight(53.0);
        btHomeNo.setPrefWidth(52.0);
        btHomeNo.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView HomeiconNo = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        HomeiconNo.setFitHeight(36.0);
        HomeiconNo.setFitWidth(32.0);
        HomeiconNo.setPreserveRatio(true);
        btHomeNo.setGraphic(HomeiconNo);
        root2.getChildren().add(btHomeNo);
        
        btHomeNo.setOnAction(e->{
         stage.setScene(sceneMany);
        stage.show();
         });
        
        Media media2 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//no//no.mp3");  
        MediaPlayer mediaPlayer2 = new MediaPlayer(media2); 
        audio2bt.setOnAction(e ->{  
        mediaPlayer2.stop(); // Stop the media if it's already playing
        mediaPlayer2.play(); // Start playing the media
         }) ;
        
        Scene sno = new Scene(root2, 800, 400);
        nextButton0.setOnAction(e->{
        stage.setScene(sno);
        stage.show();});
               //-------------word please-----
        AnchorPane rootplease = new AnchorPane();
        ImageView b5= new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
        b5.setFitWidth(800);
        b5.setPreserveRatio(true);
        rootplease.getChildren().add(b5);
        
        Text t5 = new Text("Learn Chinese");
        t5.setFill(Color.WHITE); // Change color to white
        t5.setFont(Font.font("Times new roman", FontWeight.BOLD,FontPosture.ITALIC, 38)); // Change font
        t5.setStyle("-fx-stroke: #992725;"+"-fx-stroke-width: 1;");
        t5.setLayoutX(120);
        t5.setLayoutY(59);
        t5.setTextAlignment(TextAlignment.CENTER);
        rootplease.getChildren().add(t5);
        
        Button nextButton2 = new Button("Next");
        nextButton2.setLayoutX(558);
        nextButton2.setLayoutY(347);
        nextButton2.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButton2.setTextFill(Color.WHITE);
        nextButton2.setFont(Font.font(18));
        rootplease.getChildren().add(nextButton2);
        Button backButton2 = new Button("Back");
        backButton2.setLayoutX(178);
        backButton2.setLayoutY(347);
        backButton2.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        backButton2.setTextFill(Color.WHITE);
        backButton2.setFont(Font.font(18));
        rootplease.getChildren().add(backButton2);
        
        backButton2.setOnAction(e->{
          stage.setScene(sno);
          stage.show();
        });
        Rectangle rectangle2 = new Rectangle(233, 78, 320, 215);
        rectangle2.setArcHeight(5);
        rectangle2.setArcWidth(5);
        rectangle2.setFill(Color.web("#db847092"));
        rectangle2.setStroke(Color.WHITE);
        rectangle2.setStrokeLineCap(StrokeLineCap.ROUND);
        rectangle2.setStrokeLineJoin(StrokeLineJoin.ROUND);
        rectangle2.setStrokeType(StrokeType.OUTSIDE);
        rectangle2.setStrokeWidth(2);
        rectangle2.setStyle("-fx-stroke-dash-array: 10;");
        rootplease.getChildren().add(rectangle2);
        
        Button audio3bt = new Button();
        audio3bt.setLayoutX(475);
        audio3bt.setLayoutY(174);
        audio3bt.setPrefHeight(53);
        audio3bt.setPrefWidth(52);
        ImageView audio3 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//audio.png");
        audio3.setFitHeight(55);
        audio3.setFitWidth(50);
        audio3.setLayoutX(476);
        audio3.setLayoutY(176);
        audio3bt.setGraphic(audio3);
        audio3bt.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        rootplease.getChildren().add(audio3bt);
        
        ImageView please = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//please/please.png");
        please.setFitHeight(95);
        please.setFitWidth(97);
        please.setLayoutX(278);
        please.setLayoutY(158);
        rootplease.getChildren().add(please);
       
        Text pleaseword = new Text("please");
        pleaseword.setFill(Color.web("#ffffff"));
        pleaseword.setLayoutX(295);
        pleaseword.setLayoutY(119);
        pleaseword.setFont(Font.font("Times new roman", 24));
        rootplease.getChildren().add(pleaseword);       
        Text ch3 = new Text("请");
        ch3.setFill(Color.web("#ffffff"));
        ch3.setLayoutX(480);
        ch3.setLayoutY(121);
        ch3.setFont(Font.font("Times new roman",26));
        rootplease.getChildren().add(ch3);
        
        
        Button btHomePlease = new Button();
        btHomePlease.setLayoutX(50.0);
        btHomePlease.setLayoutY(21.0);
        btHomePlease.setMnemonicParsing(false);
        btHomePlease.setPrefHeight(53.0);
        btHomePlease.setPrefWidth(52.0);
        btHomePlease.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView HomeiconPlease = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        HomeiconPlease.setFitHeight(36.0);
        HomeiconPlease.setFitWidth(32.0);
        HomeiconPlease.setPreserveRatio(true);
        btHomePlease.setGraphic(HomeiconPlease);
        rootplease.getChildren().add(btHomePlease); 
        
         btHomePlease.setOnAction(e->{
         stage.setScene(sceneMany);
        stage.show();
         });
        
        Media media3 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images/please/please.mp3");  
        MediaPlayer mediaPlayer3 = new MediaPlayer(media3); 
        audio3bt.setOnAction(e ->{  
        mediaPlayer3.stop(); // Stop the media if it's already playing
        mediaPlayer3.play(); // Start playing the media
         }) ;
        
                Scene pleaseScene = new Scene(rootplease, 800, 400);
        nextButton1.setOnAction(e->{
        stage.setScene(pleaseScene);
        stage.show();});
        
       //-------------word thanks-----
        AnchorPane rootthanks = new AnchorPane();
        ImageView b6= new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
        b6.setFitWidth(800);
        b6.setPreserveRatio(true);
        rootthanks.getChildren().add(b6);
        
        Text t6 = new Text("Learn Chinese");
        t6.setFill(Color.WHITE); // Change color to white
        t6.setFont(Font.font("Times new roman", FontWeight.BOLD,FontPosture.ITALIC, 38)); // Change font
        t6.setStyle("-fx-stroke: #992725;"+"-fx-stroke-width: 1;");
        t6.setLayoutX(120);
        t6.setLayoutY(59);
        t6.setTextAlignment(TextAlignment.CENTER);
        rootthanks.getChildren().add(t6);
        
        Button nextButtonthank = new Button("Next");
        nextButtonthank.setLayoutX(558);
        nextButtonthank.setLayoutY(347);
        nextButtonthank.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButtonthank.setTextFill(Color.WHITE);
        nextButtonthank.setFont(Font.font(18));
        rootthanks.getChildren().add(nextButtonthank);
        Button backButton3 = new Button("Back");
        backButton3.setLayoutX(178);
        backButton3.setLayoutY(347);
        backButton3.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        backButton3.setTextFill(Color.WHITE);
        backButton3.setFont(Font.font(18));
        rootthanks.getChildren().add(backButton3);
      
        Rectangle rectangle3 = new Rectangle(233, 78, 320, 215);
        rectangle3.setArcHeight(5);
        rectangle3.setArcWidth(5);
        rectangle3.setFill(Color.web("#db847092"));
        rectangle3.setStroke(Color.WHITE);
        rectangle3.setStrokeLineCap(StrokeLineCap.ROUND);
        rectangle3.setStrokeLineJoin(StrokeLineJoin.ROUND);
        rectangle3.setStrokeType(StrokeType.OUTSIDE);
        rectangle3.setStrokeWidth(2);
        rectangle3.setStyle("-fx-stroke-dash-array: 10;");
        rootthanks.getChildren().add(rectangle3);
        
        Button audio4bt = new Button();
        audio4bt.setLayoutX(475);
        audio4bt.setLayoutY(174);
        audio4bt.setPrefHeight(53);
        audio4bt.setPrefWidth(52);
        ImageView audio4 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//audio.png");
        audio4.setFitHeight(55);
        audio4.setFitWidth(50);
        audio4.setLayoutX(476);
        audio4.setLayoutY(176);
        audio4bt.setGraphic(audio4);
        audio4bt.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        rootthanks.getChildren().add(audio4bt);
        
        ImageView thanks = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//thanks/thanks.png");
        thanks.setFitHeight(95);
        thanks.setFitWidth(97);
        thanks.setLayoutX(278);
        thanks.setLayoutY(158);
        rootthanks.getChildren().add(thanks);
       
        Text thankword = new Text("Thank You");
        thankword.setFill(Color.web("#ffffff"));
        thankword.setLayoutX(295);
        thankword.setLayoutY(119);
        thankword.setFont(Font.font("Times new roman", 24));
        rootthanks.getChildren().add(thankword);       
        Text ch4 = new Text("谢谢");
        ch4.setFill(Color.web("#ffffff"));
        ch4.setLayoutX(480);
        ch4.setLayoutY(121);
        ch4.setFont(Font.font("Times new roman",26));
        rootthanks.getChildren().add(ch4);
        
        Button btHomeThank = new Button();
        btHomeThank.setLayoutX(50.0);
        btHomeThank.setLayoutY(21.0);
        btHomeThank.setMnemonicParsing(false);
        btHomeThank.setPrefHeight(53.0);
        btHomeThank.setPrefWidth(52.0);
        btHomeThank.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView Homeiconthank = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        Homeiconthank.setFitHeight(36.0);
        Homeiconthank.setFitWidth(32.0);
        Homeiconthank.setPreserveRatio(true);
        btHomeThank.setGraphic(Homeiconthank);
        rootthanks.getChildren().add(btHomeThank);
        
         btHomeThank.setOnAction(e->{
         stage.setScene(sceneMany);
        stage.show();
         });
         
        Media media4 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images/thanks/thanks.mp3");  
        MediaPlayer mediaPlayer4 = new MediaPlayer(media4); 
        audio4bt.setOnAction(e ->{  
        mediaPlayer4.stop(); // Stop the media if it's already playing
        mediaPlayer4.play(); // Start playing the media
         }) ; 
        
        //----------actions buttons---
          backButton3.setOnAction(e->{
          stage.setScene(pleaseScene);
          stage.show();
        });  
        Scene thanksScene = new Scene(rootthanks, 800, 400);
        nextButton2.setOnAction(e->{
        stage.setScene(thanksScene);
        stage.show();});

        //--------------(((((Big word)))))))))))))-----------------
        AnchorPane rootBig = new AnchorPane();
        ImageView b6Big = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
        b6Big.setFitWidth(800);
        b6Big.setPreserveRatio(true);
        rootBig.getChildren().add(b6Big);

        Text t6Big = new Text("Learn Chinese");
        t6Big.setFill(Color.WHITE);
        t6Big.setFont(Font.font("Times new roman", FontWeight.BOLD, FontPosture.ITALIC, 38));
        t6Big.setStyle("-fx-stroke: #992725;" + "-fx-stroke-width: 1;");
        t6Big.setLayoutX(120);
        t6Big.setLayoutY(59);
        t6Big.setTextAlignment(TextAlignment.CENTER);
        rootBig.getChildren().add(t6Big);

        Button nextButtonBig = new Button("Next");
        nextButtonBig.setLayoutX(558);
        nextButtonBig.setLayoutY(347);
        nextButtonBig.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButtonBig.setTextFill(Color.WHITE);
        nextButtonBig.setFont(Font.font(18));
        rootBig.getChildren().add(nextButtonBig);
        Button backButtonBig = new Button("Back");
        backButtonBig.setLayoutX(178);
        backButtonBig.setLayoutY(347);
        backButtonBig.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        backButtonBig.setTextFill(Color.WHITE);
        backButtonBig.setFont(Font.font(18));
        rootBig.getChildren().add(backButtonBig);

        Rectangle rectangleBig = new Rectangle(233, 78, 320, 215);
        rectangleBig.setArcHeight(5);
        rectangleBig.setArcWidth(5);
        rectangleBig.setFill(Color.web("#db847092"));
        rectangleBig.setStroke(Color.WHITE);
        rectangleBig.setStrokeLineCap(StrokeLineCap.ROUND);
        rectangleBig.setStrokeLineJoin(StrokeLineJoin.ROUND);
        rectangleBig.setStrokeType(StrokeType.OUTSIDE);
        rectangleBig.setStrokeWidth(2);
        rectangleBig.setStyle("-fx-stroke-dash-array: 10;");
        rootBig.getChildren().add(rectangleBig);

        Button audioBigBt = new Button();
        audioBigBt.setLayoutX(475);
        audioBigBt.setLayoutY(174);
        audioBigBt.setPrefHeight(53);
        audioBigBt.setPrefWidth(52);
        ImageView audioBig = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//audio.png");
        audioBig.setFitHeight(55);
        audioBig.setFitWidth(50);
        audioBig.setLayoutX(476);
        audioBig.setLayoutY(176);
        audioBigBt.setGraphic(audioBig);
        audioBigBt.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        rootBig.getChildren().add(audioBigBt);

        ImageView bigImage = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//big/big.png");
        bigImage.setFitHeight(95);
        bigImage.setFitWidth(97);
        bigImage.setLayoutX(278);
        bigImage.setLayoutY(158);
        rootBig.getChildren().add(bigImage);

        Text bigw = new Text("Big");
        bigw.setFill(Color.web("#ffffff"));
        bigw.setLayoutX(295);
        bigw.setLayoutY(119);
        bigw.setFont(Font.font("Times new roman", 24));
        rootBig.getChildren().add(bigw); 
        Text bigWord = new Text("大");
        bigWord.setFill(Color.web("#ffffff"));
        bigWord.setLayoutX(480);
        bigWord.setLayoutY(121);
        bigWord.setFont(Font.font("Times new roman",26));
        rootBig.getChildren().add(bigWord);
        
        Button btHomebig = new Button();
        btHomebig.setLayoutX(50.0);
        btHomebig.setLayoutY(21.0);
        btHomebig.setMnemonicParsing(false);
        btHomebig.setPrefHeight(53.0);
        btHomebig.setPrefWidth(52.0);
        btHomebig.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView Homeiconbig = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        Homeiconbig.setFitHeight(36.0);
        Homeiconbig.setFitWidth(32.0);
        Homeiconbig.setPreserveRatio(true);
        btHomebig.setGraphic(Homeiconbig);
        rootBig.getChildren().add(btHomebig);

         btHomebig.setOnAction(e->{
         stage.setScene(sceneMany);
        stage.show();
         });
         
        Media mediaBig = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//big/big.mp3");
        MediaPlayer mediaPlayerBig = new MediaPlayer(mediaBig);
        audioBigBt.setOnAction(e -> {
            mediaPlayerBig.stop();
            mediaPlayerBig.play();
        });

        //----------actions buttons---
        backButtonBig.setOnAction(e -> {
            stage.setScene(thanksScene);
            stage.show();
        });
        Scene bigScene = new Scene(rootBig, 800, 400);
        nextButtonthank.setOnAction(e -> {
            stage.setScene(bigScene);
            stage.show();
        });

        //--------------(((((((((small word)))))))))))-----------------
        AnchorPane rootSmall = new AnchorPane();
        ImageView b6Small = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
        b6Small.setFitWidth(800);
        b6Small.setPreserveRatio(true);
        rootSmall.getChildren().add(b6Small);

        Text t6Small = new Text("Learn Chinese");
        t6Small.setFill(Color.WHITE);
        t6Small.setFont(Font.font("Times new roman", FontWeight.BOLD, FontPosture.ITALIC, 38));
        t6Small.setStyle("-fx-stroke: #992725;" + "-fx-stroke-width: 1;");
        t6Small.setLayoutX(120);
        t6Small.setLayoutY(59);
        t6Small.setTextAlignment(TextAlignment.CENTER);
        rootSmall.getChildren().add(t6Small);

        Button nextButtonSmall = new Button("Next");
        nextButtonSmall.setLayoutX(558);
        nextButtonSmall.setLayoutY(347);
        nextButtonSmall.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButtonSmall.setTextFill(Color.WHITE);
        nextButtonSmall.setFont(Font.font(18));
        rootSmall.getChildren().add(nextButtonSmall);
        Button backButtonSmall = new Button("Back");
        backButtonSmall.setLayoutX(178);
        backButtonSmall.setLayoutY(347);
        backButtonSmall.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        backButtonSmall.setTextFill(Color.WHITE);
        backButtonSmall.setFont(Font.font(18));
        rootSmall.getChildren().add(backButtonSmall);

        Rectangle rectangleSmall = new Rectangle(233, 78, 320, 215);
        rectangleSmall.setArcHeight(5);
        rectangleSmall.setArcWidth(5);
        rectangleSmall.setFill(Color.web("#db847092"));
        rectangleSmall.setStroke(Color.WHITE);
        rectangleSmall.setStrokeLineCap(StrokeLineCap.ROUND);
        rectangleSmall.setStrokeLineJoin(StrokeLineJoin.ROUND);
        rectangleSmall.setStrokeType(StrokeType.OUTSIDE);
        rectangleSmall.setStrokeWidth(2);
        rectangleSmall.setStyle("-fx-stroke-dash-array: 10;");
        rootSmall.getChildren().add(rectangleSmall);

        Button audioSmallBt = new Button();
        audioSmallBt.setLayoutX(475);
        audioSmallBt.setLayoutY(174);
        audioSmallBt.setPrefHeight(53);
        audioSmallBt.setPrefWidth(52);
        ImageView audioSmall = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//audio.png");
        audioSmall.setFitHeight(55);
        audioSmall.setFitWidth(50);
        audioSmall.setLayoutX(476);
        audioSmall.setLayoutY(176);
        audioSmallBt.setGraphic(audioSmall);
        audioSmallBt.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        rootSmall.getChildren().add(audioSmallBt);

        ImageView smallImage = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//small/small.png");
        smallImage.setFitHeight(95);
        smallImage.setFitWidth(97);
        smallImage.setLayoutX(278);
        smallImage.setLayoutY(158);
        rootSmall.getChildren().add(smallImage);

        Text smallw = new Text("Small");
        smallw.setFill(Color.web("#ffffff"));
        smallw.setLayoutX(295);
        smallw.setLayoutY(119);
        smallw.setFont(Font.font("Times new roman", 24));
        rootSmall.getChildren().add(smallw); 
        Text smallWord = new Text("小");
        smallWord.setFill(Color.web("#ffffff"));
        smallWord.setLayoutX(480);
        smallWord.setLayoutY(121);
        smallWord.setFont(Font.font("Times new roman",26));
        rootSmall.getChildren().add(smallWord);
        
        Button btHomesmall = new Button();
        btHomesmall.setLayoutX(50.0);
        btHomesmall.setLayoutY(21.0);
        btHomesmall.setMnemonicParsing(false);
        btHomesmall.setPrefHeight(53.0);
        btHomesmall.setPrefWidth(52.0);
        btHomesmall.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView Homeiconsmall = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        Homeiconsmall.setFitHeight(36.0);
        Homeiconsmall.setFitWidth(32.0);
        Homeiconsmall.setPreserveRatio(true);
        btHomesmall.setGraphic(Homeiconsmall);
        rootSmall.getChildren().add(btHomesmall);
         btHomesmall.setOnAction(e->{
         stage.setScene(sceneMany);
        stage.show();
         });

        Media mediaSmall = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//small/small.mp3");
        MediaPlayer mediaPlayerSmall = new MediaPlayer(mediaSmall);
        audioSmallBt.setOnAction(e -> {
            mediaPlayerSmall.stop();
            mediaPlayerSmall.play();
        });

        //----------actions buttons---
        backButtonSmall.setOnAction(e -> {
            stage.setScene(bigScene);
            stage.show();
        });
        Scene smallScene = new Scene(rootSmall, 800, 400);
        nextButtonBig.setOnAction(e -> {
            stage.setScene(smallScene);
            stage.show();
        });

        //--------------and word-----------------
        AnchorPane rootAnd = new AnchorPane();
        ImageView b6And = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
        b6And.setFitWidth(800);
        b6And.setPreserveRatio(true);
        rootAnd.getChildren().add(b6And);

        Text t6And = new Text("Learn Chinese");
        t6And.setFill(Color.WHITE);
        t6And.setFont(Font.font("Times new roman", FontWeight.BOLD, FontPosture.ITALIC, 38));
        t6And.setStyle("-fx-stroke: #992725;" + "-fx-stroke-width: 1;");
        t6And.setLayoutX(120);
        t6And.setLayoutY(59);
        t6And.setTextAlignment(TextAlignment.CENTER);
        rootAnd.getChildren().add(t6And);

        Button nextButtonAnd = new Button("Next");
        nextButtonAnd.setLayoutX(558);
        nextButtonAnd.setLayoutY(347);
        nextButtonAnd.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButtonAnd.setTextFill(Color.WHITE);
        nextButtonAnd.setFont(Font.font(18));
        rootAnd.getChildren().add(nextButtonAnd);
        Button backButtonAnd = new Button("Back");
        backButtonAnd.setLayoutX(178);
        backButtonAnd.setLayoutY(347);
        backButtonAnd.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        backButtonAnd.setTextFill(Color.WHITE);
        backButtonAnd.setFont(Font.font(18));
        rootAnd.getChildren().add(backButtonAnd);

        Rectangle rectangleAnd = new Rectangle(233, 78, 320, 215);
        rectangleAnd.setArcHeight(5);
        rectangleAnd.setArcWidth(5);
        rectangleAnd.setFill(Color.web("#db847092"));
        rectangleAnd.setStroke(Color.WHITE);
        rectangleAnd.setStrokeLineCap(StrokeLineCap.ROUND);
        rectangleAnd.setStrokeLineJoin(StrokeLineJoin.ROUND);
        rectangleAnd.setStrokeType(StrokeType.OUTSIDE);
        rectangleAnd.setStrokeWidth(2);
        rectangleAnd.setStyle("-fx-stroke-dash-array: 10;");
        rootAnd.getChildren().add(rectangleAnd);

        Button audioAndBt = new Button();
        audioAndBt.setLayoutX(475);
        audioAndBt.setLayoutY(174);
        audioAndBt.setPrefHeight(53);
        audioAndBt.setPrefWidth(52);
        ImageView audioAnd = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//audio.png");
        audioAnd.setFitHeight(55);
        audioAnd.setFitWidth(50);
        audioAnd.setLayoutX(476);
        audioAnd.setLayoutY(176);
        audioAndBt.setGraphic(audioAnd);
        audioAndBt.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        rootAnd.getChildren().add(audioAndBt);

        ImageView andImage = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//and/and.png");
        andImage.setFitHeight(95);
        andImage.setFitWidth(97);
        andImage.setLayoutX(278);
        andImage.setLayoutY(158);
        rootAnd.getChildren().add(andImage);

        Text andw = new Text("And");
        andw.setFill(Color.web("#ffffff"));
        andw.setLayoutX(295);
        andw.setLayoutY(119);
        andw.setFont(Font.font("Times new roman", 24));
        rootAnd.getChildren().add(andw); 
        Text andWord = new Text("和");
        andWord.setFill(Color.web("#ffffff"));
        andWord.setLayoutX(480);
        andWord.setLayoutY(121);
        andWord.setFont(Font.font("Times new roman",26));
        rootAnd.getChildren().add(andWord);
        
        Button btHomeand = new Button();
        btHomeand.setLayoutX(50.0);
        btHomeand.setLayoutY(21.0);
        btHomeand.setMnemonicParsing(false);
        btHomeand.setPrefHeight(53.0);
        btHomeand.setPrefWidth(52.0);
        btHomeand.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView Homeiconand = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        Homeiconand.setFitHeight(36.0);
        Homeiconand.setFitWidth(32.0);
        Homeiconand.setPreserveRatio(true);
        btHomeand.setGraphic(Homeiconand);
        rootAnd.getChildren().add(btHomeand);

         btHomeand.setOnAction(e->{
         stage.setScene(sceneMany);
        stage.show();
         });
        
        Media mediaAnd = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//and/and.mp3");
        MediaPlayer mediaPlayerAnd = new MediaPlayer(mediaAnd);
        audioAndBt.setOnAction(e -> {
            mediaPlayerAnd.stop();
            mediaPlayerAnd.play();
        });

        //----------actions buttons---
        backButtonAnd.setOnAction(e -> {
            stage.setScene(smallScene);
            stage.show();
        });
        Scene andScene = new Scene(rootAnd, 800, 400);
        nextButtonSmall.setOnAction(e -> {
            stage.setScene(andScene);
            stage.show();
        });
        //-------------word or ------------
        AnchorPane rootOr = new AnchorPane();
        ImageView b6Or = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
        b6Or.setFitWidth(800);
        b6Or.setPreserveRatio(true);
        rootOr.getChildren().add(b6Or);

        Text t6Or = new Text("Learn Chinese");
        t6Or.setFill(Color.WHITE);
        t6Or.setFont(Font.font("Times new roman", FontWeight.BOLD, FontPosture.ITALIC, 38));
        t6Or.setStyle("-fx-stroke: #992725;" + "-fx-stroke-width: 1;");
        t6Or.setLayoutX(120);
        t6Or.setLayoutY(59);
        t6Or.setTextAlignment(TextAlignment.CENTER);
        rootOr.getChildren().add(t6Or);

        Button nextButtonOr = new Button("Next");
        nextButtonOr.setLayoutX(558);
        nextButtonOr.setLayoutY(347);
        nextButtonOr.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButtonOr.setTextFill(Color.WHITE);
        nextButtonOr.setFont(Font.font(18));
        rootOr.getChildren().add(nextButtonOr);
        Button backButtonOr = new Button("Back");
        backButtonOr.setLayoutX(178);
        backButtonOr.setLayoutY(347);
        backButtonOr.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        backButtonOr.setTextFill(Color.WHITE);
        backButtonOr.setFont(Font.font(18));
        rootOr.getChildren().add(backButtonOr);

        Rectangle rectangleOr = new Rectangle(233, 78, 320, 215);
        rectangleOr.setArcHeight(5);
        rectangleOr.setArcWidth(5);
        rectangleOr.setFill(Color.web("#db847092"));
        rectangleOr.setStroke(Color.WHITE);
        rectangleOr.setStrokeLineCap(StrokeLineCap.ROUND);
        rectangleOr.setStrokeLineJoin(StrokeLineJoin.ROUND);
        rectangleOr.setStrokeType(StrokeType.OUTSIDE);
        rectangleOr.setStrokeWidth(2);
        rectangleOr.setStyle("-fx-stroke-dash-array: 10;");
        rootOr.getChildren().add(rectangleOr);

        Button audioOrBt = new Button();
        audioOrBt.setLayoutX(475);
        audioOrBt.setLayoutY(174);
        audioOrBt.setPrefHeight(53);
        audioOrBt.setPrefWidth(52);
        ImageView audioOr = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//audio.png");
        audioOr.setFitHeight(55);
        audioOr.setFitWidth(50);
        audioOr.setLayoutX(476);
        audioOr.setLayoutY(176);
        audioOrBt.setGraphic(audioOr);
        audioOrBt.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        rootOr.getChildren().add(audioOrBt);

        ImageView orImage = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//or/or.png");
        orImage.setFitHeight(95);
        orImage.setFitWidth(97);
        orImage.setLayoutX(278);
        orImage.setLayoutY(158);
        rootOr.getChildren().add(orImage);
 
        Text orw = new Text("Or");
        orw.setFill(Color.web("#ffffff"));
        orw.setLayoutX(295);
        orw.setLayoutY(119);
        orw.setFont(Font.font("Times new roman", 24));
        rootOr.getChildren().add(orw); 
        Text orWord = new Text("或");
        orWord.setFill(Color.web("#ffffff"));
        orWord.setLayoutX(480);
        orWord.setLayoutY(121);
        orWord.setFont(Font.font("Times new roman", 26));
        rootOr.getChildren().add(orWord);
        
        Button btHomeor = new Button();
        btHomeor.setLayoutX(50.0);
        btHomeor.setLayoutY(21.0);
        btHomeor.setMnemonicParsing(false);
        btHomeor.setPrefHeight(53.0);
        btHomeor.setPrefWidth(52.0);
        btHomeor.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView Homeiconor = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        Homeiconor.setFitHeight(36.0);
        Homeiconor.setFitWidth(32.0);
        Homeiconor.setPreserveRatio(true);
        btHomeor.setGraphic(Homeiconor);
        rootOr.getChildren().add(btHomeor);

         btHomeor.setOnAction(e->{
         stage.setScene(sceneMany);
        stage.show();
         });
         
        Media mediaOr = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//or/or.mp3");
        MediaPlayer mediaPlayerOr = new MediaPlayer(mediaOr);
        audioOrBt.setOnAction(e -> {
            mediaPlayerOr.stop();
            mediaPlayerOr.play();
        });

        //----------actions buttons---
        backButtonOr.setOnAction(e -> {
            stage.setScene(andScene);
            stage.show();
        });
        Scene orScene = new Scene(rootOr, 800, 400);
        nextButtonAnd.setOnAction(e -> {
            stage.setScene(orScene);
            stage.show();
        });

        //-------------word okay-----
        AnchorPane rootOkay = new AnchorPane();
        ImageView b6Okay = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
        b6Okay.setFitWidth(800);
        b6Okay.setPreserveRatio(true);
        rootOkay.getChildren().add(b6Okay);

        Text t6Okay = new Text("Learn Chinese");
        t6Okay.setFill(Color.WHITE);
        t6Okay.setFont(Font.font("Times new roman", FontWeight.BOLD, FontPosture.ITALIC, 38));
        t6Okay.setStyle("-fx-stroke: #992725;" + "-fx-stroke-width: 1;");
        t6Okay.setLayoutX(120);
        t6Okay.setLayoutY(59);
        t6Okay.setTextAlignment(TextAlignment.CENTER);
        rootOkay.getChildren().add(t6Okay);

        Button nextButtonOkay = new Button("Next");
        nextButtonOkay.setLayoutX(558);
        nextButtonOkay.setLayoutY(347);
        nextButtonOkay.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButtonOkay.setTextFill(Color.WHITE);
        nextButtonOkay.setFont(Font.font(18));
        rootOkay.getChildren().add(nextButtonOkay);
        Button backButtonOkay = new Button("Back");
        backButtonOkay.setLayoutX(178);
        backButtonOkay.setLayoutY(347);
        backButtonOkay.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        backButtonOkay.setTextFill(Color.WHITE);
        backButtonOkay.setFont(Font.font(18));
        rootOkay.getChildren().add(backButtonOkay);

        Rectangle rectangleOkay = new Rectangle(233, 78, 320, 215);
        rectangleOkay.setArcHeight(5);
        rectangleOkay.setArcWidth(5);
        rectangleOkay.setFill(Color.web("#db847092"));
        rectangleOkay.setStroke(Color.WHITE);
        rectangleOkay.setStrokeLineCap(StrokeLineCap.ROUND);
        rectangleOkay.setStrokeLineJoin(StrokeLineJoin.ROUND);
        rectangleOkay.setStrokeType(StrokeType.OUTSIDE);
        rectangleOkay.setStrokeWidth(2);
        rectangleOkay.setStyle("-fx-stroke-dash-array: 10;");
        rootOkay.getChildren().add(rectangleOkay);

        Button audioOkayBt = new Button();
        audioOkayBt.setLayoutX(475);
        audioOkayBt.setLayoutY(174);
        audioOkayBt.setPrefHeight(53);
        audioOkayBt.setPrefWidth(52);
        ImageView audioOkay = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//audio.png");
        audioOkay.setFitHeight(55);
        audioOkay.setFitWidth(50);
        audioOkay.setLayoutX(476);
        audioOkay.setLayoutY(176);
        audioOkayBt.setGraphic(audioOkay);
        audioOkayBt.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        rootOkay.getChildren().add(audioOkayBt);

        ImageView okayImage = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//ok/okay.png");
        okayImage.setFitHeight(95);
        okayImage.setFitWidth(97);
        okayImage.setLayoutX(278);
        okayImage.setLayoutY(158);
        rootOkay.getChildren().add(okayImage);

        Text okw = new Text("Okay");
        okw.setFill(Color.web("#ffffff"));
        okw.setLayoutX(295);
        okw.setLayoutY(119);
        okw.setFont(Font.font("Times new roman", 24));
        rootOkay.getChildren().add(okw);
        Text okayWord = new Text("好");
        okayWord.setFill(Color.WHITE);
        okayWord.setLayoutX(480);
        okayWord.setLayoutY(121);
        okayWord.setFont(Font.font("Times new roman",26));
        rootOkay.getChildren().add(okayWord);
        

        Button btHomeok = new Button();
        btHomeok.setLayoutX(50.0);
        btHomeok.setLayoutY(21.0);
        btHomeok.setMnemonicParsing(false);
        btHomeok.setPrefHeight(53.0);
        btHomeok.setPrefWidth(52.0);
        btHomeok.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView Homeiconok = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        Homeiconok.setFitHeight(36.0);
        Homeiconok.setFitWidth(32.0);
        Homeiconok.setPreserveRatio(true);
        btHomeok.setGraphic(Homeiconok);
        rootOkay.getChildren().add(btHomeok);
        
         btHomeok.setOnAction(e->{
         stage.setScene(sceneMany);
        stage.show();
         });
         
        Media mediaOkay = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//ok//okay.mp3");
        MediaPlayer mediaPlayerOkay = new MediaPlayer(mediaOkay);
        audioOkayBt.setOnAction(e -> {
            mediaPlayerOkay.stop();
            mediaPlayerOkay.play();
        });

        
        //----------actions buttons---
        backButtonOkay.setOnAction(e -> {
            stage.setScene(orScene);
            stage.show();
        });
        Scene okayScene = new Scene(rootOkay, 800, 400);
        nextButtonOr.setOnAction(e -> {
            stage.setScene(okayScene);
            stage.show();
        });
        //---------------Bye word-------------
        AnchorPane rootBye = new AnchorPane();
        ImageView bBye= new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
        bBye.setFitWidth(800);
        bBye.setPreserveRatio(true);
        rootBye.getChildren().add(bBye);
        
        Text tbye = new Text("Learn Chinese");
        tbye.setFill(Color.WHITE); // Change color to white
        tbye.setFont(Font.font("Times new roman", FontWeight.BOLD,FontPosture.ITALIC, 38)); // Change font
        tbye.setStyle("-fx-stroke: #992725;"+"-fx-stroke-width: 1;");
        tbye.setLayoutX(120);
        tbye.setLayoutY(59);
        tbye.setTextAlignment(TextAlignment.CENTER);
        rootBye.getChildren().add(tbye);
        
        Button backButtonBye = new Button("Back");
        backButtonBye.setLayoutX(178);
        backButtonBye.setLayoutY(347);
        backButtonBye.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        backButtonBye.setTextFill(Color.WHITE);
        backButtonBye.setFont(Font.font(18));
        rootBye.getChildren().add(backButtonBye);
      
        Rectangle rectangleBye = new Rectangle(233, 78, 320, 215);
        rectangleBye.setArcHeight(5);
        rectangleBye.setArcWidth(5);
        rectangleBye.setFill(Color.web("#db847092"));
        rectangleBye.setStroke(Color.WHITE);
        rectangleBye.setStrokeLineCap(StrokeLineCap.ROUND);
        rectangleBye.setStrokeLineJoin(StrokeLineJoin.ROUND);
        rectangleBye.setStrokeType(StrokeType.OUTSIDE);
        rectangleBye.setStrokeWidth(2);
        rectangleBye.setStyle("-fx-stroke-dash-array: 10;");
        rootBye.getChildren().add(rectangleBye);
        
        ImageView byeImage = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//bye/bye.png");
        byeImage.setFitHeight(95);
        byeImage.setFitWidth(97);
        byeImage.setLayoutX(278);
        byeImage.setLayoutY(158);
        rootBye.getChildren().add(byeImage);
       
        Text Byeword = new Text("Goodbye");
        Byeword.setFill(Color.web("#ffffff"));
        Byeword.setLayoutX(295);
        Byeword.setLayoutY(119);
        Byeword.setFont(Font.font("Times new roman", 24));
        rootBye.getChildren().add(Byeword);       
        Text byeCh = new Text("再见");
        byeCh.setFill(Color.web("#ffffff"));
        byeCh.setLayoutX(480);
        byeCh.setLayoutY(121);
        byeCh.setFont(Font.font(26));
        rootBye.getChildren().add(byeCh);
        
        Button byeHome= new Button();
        byeHome.setLayoutX(50.0);
        byeHome.setLayoutY(21.0);
        byeHome.setMnemonicParsing(false);
        byeHome.setPrefHeight(53.0);
        byeHome.setPrefWidth(52.0);
        byeHome.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView Homebyeicon = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        Homebyeicon.setFitHeight(36.0);
        Homebyeicon.setFitWidth(32.0);
        Homebyeicon.setPreserveRatio(true);
        byeHome.setGraphic(Homebyeicon);
        rootBye.getChildren().add(byeHome);
        
          byeHome.setOnAction(e->{
         stage.setScene(sceneMany);
        stage.show();
         });
         
        
        Button audioByebt = new Button();
        audioByebt.setLayoutX(475);
        audioByebt.setLayoutY(174);
        audioByebt.setPrefHeight(53);
        audioByebt.setPrefWidth(52);
        ImageView audioByeImage = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//audio.png");
        audioByeImage.setFitHeight(55);
        audioByeImage.setFitWidth(50);
        audioByeImage.setLayoutX(476);
        audioByeImage.setLayoutY(176);
        audioByebt.setGraphic(audioByeImage);
        audioByebt.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        rootBye.getChildren().add(audioByebt);
        
        Media byeMp = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images/bye/bye.mp3");  
        MediaPlayer playerBye = new MediaPlayer(byeMp); 
        audioByebt.setOnAction(e ->{  
        playerBye.stop(); // Stop the media if it's already playing
        playerBye.play(); // Start playing the media
         }) ; 
        //----------actions buttons---
          backButtonBye.setOnAction(e->{
          stage.setScene(okayScene);
          stage.show();
        });
        Scene byeScene = new Scene(rootBye, 800, 400);
        nextButtonOkay.setOnAction(e->{
        stage.setScene(byeScene);
        stage.show();}); 
    //-------------**********Scene test*******************---------------------
       //-----------------------test level -------------------
          ImageView backgroundTest=new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
        backgroundTest.setFitWidth(800);
        backgroundTest.setFitHeight(400);
        
        Button btHomeTest = new Button();
        btHomeTest.setLayoutX(50.0);
        btHomeTest.setLayoutY(21.0);
        btHomeTest.setMnemonicParsing(false);
        btHomeTest.setPrefHeight(53.0);
        btHomeTest.setPrefWidth(52.0);
        btHomeTest.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView HomeiconTest = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        HomeiconTest.setFitHeight(36.0);
        HomeiconTest.setFitWidth(32.0);
        HomeiconTest.setPreserveRatio(true);
        btHomeTest.setGraphic(HomeiconTest);
       

         // Create a title label and add it to the center
        Label titleLabel = new Label("Test Level");
        titleLabel.setFont(Font.font("Times new roman", FontWeight.EXTRA_BOLD, 60));
        titleLabel.setTextFill(Color.rgb(188,42,38));
        titleLabel.setLayoutX(250);
        titleLabel.setLayoutY(80);
        
        VBox optionBox = new VBox(20);
       optionBox.setAlignment(Pos.CENTER);
        
       Button button1 = new Button("Easy");
       button1.setFont(Font.font("Times new roman", FontWeight.BOLD,23));
       button1.setTextFill(Color.WHITE);
       button1.setStyle("-fx-background-color: rgba(167, 75, 54, 0.5); -fx-border-color: white; -fx-border-width: 3; -fx-border-radius: 2; -fx-border-style:dashed");
       button1.setPadding(new Insets(10, 20, 10, 20));
       button1.setPrefSize(180, 40);
        
       Button button2 = new Button("Middle");
       button2.setFont(Font.font("Times new roman", FontWeight.BOLD,23));
       button2.setTextFill(Color.WHITE);
       button2.setStyle("-fx-background-color: rgba(167, 75, 54, 0.5); -fx-border-color: white; -fx-border-width: 3; -fx-border-radius: 2; -fx-border-style:dashed");
       button2.setPadding(new Insets(10, 20, 10, 20));
  //     Image lockImage = new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//lock.png"); // Replace with your image path
    //   ImageView lockIcon = new ImageView(lockImage);
      // lockIcon.setFitWidth(20);
//       lockIcon.setFitHeight(20);
  //     button2.setGraphic(lockIcon);
       button2.setContentDisplay(ContentDisplay.RIGHT); 
       button2.setGraphicTextGap(10);
       button2.setPrefSize(180, 40);
  
       Button button3 = new Button("Difficult");
       button3.setFont(Font.font("Times new roman", FontWeight.BOLD,23));
       button3.setTextFill(Color.WHITE);
       button3.setStyle("-fx-background-color: rgba(167, 75, 54, 0.5); -fx-border-color: white; -fx-border-width: 3; -fx-border-radius: 2; -fx-border-style:dashed");
       button3.setPadding(new Insets(10, 20, 10, 20));
//       Image lockImage1 = new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//lock.png"); // Replace with your image path
//       ImageView lockIcon1 = new ImageView(lockImage1);
//       lockIcon1.setFitWidth(20);
//       lockIcon1.setFitHeight(20);
//       button3.setGraphic(lockIcon1);
       button3.setContentDisplay(ContentDisplay.RIGHT); 
       button3.setGraphicTextGap(10);
       button3.setPrefSize(180, 40);

       optionBox.setLayoutX(250);
       optionBox.setLayoutY(130);
       optionBox.setPrefWidth(300);
       optionBox.setPrefHeight(250);
      
       optionBox.getChildren().addAll(button1,button2,button3);

           // optionBox.setStyle("-fx-background-color: rgba(167, 75, 54, 0.5); -fx-border-style: dashed; -fx-border-width: 3; -fx-border-color: white; -fx-border-radius: 5;");
            optionBox.setLayoutX(250);
            optionBox.setLayoutY(130);
            optionBox.setPrefWidth(300);
            optionBox.setPrefHeight(250);
                    
            // Add Rectangle for score
        AnchorPane anchorPane_test= new AnchorPane();
        Rectangle scoreRectangle = new Rectangle(173, 36);
       scoreRectangle.setArcWidth(5.0);
        scoreRectangle.setArcHeight(5.0);
        scoreRectangle.setFill(Color.web("#d98471a3"));
        scoreRectangle.setLayoutX(565.0);
        scoreRectangle.setLayoutY(29.0);
        scoreRectangle.setStroke(Color.WHITE);
        scoreRectangle.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
        scoreRectangle.setStrokeLineJoin(javafx.scene.shape.StrokeLineJoin.ROUND);
        scoreRectangle.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        scoreRectangle.setStrokeWidth(2.0);
        scoreRectangle.setStyle("-fx-stroke-dash-array: 8;");
        anchorPane_test.getChildren().add(scoreRectangle);

        // Add Label for score
        Label scoreLabel = new Label(Integer.toString(score));
        scoreLabel.setLayoutX(679.0);
        scoreLabel.setLayoutY(32.0);
        scoreLabel.setTextFill(Color.web("#6d4239"));
        scoreLabel.setFont(Font.font("Imprint MT Shadow", 26.0));
        scoreLabel.setText(Integer.toString(score));
        anchorPane_test.getChildren().add(scoreLabel);

        // Add Text "Score:"
        Text scoreText = new Text("Score:");
        scoreText.setFill(Color.web("#52352f"));
        scoreText.setFont(Font.font("Imprint MT Shadow", 26.0));
        scoreText.setLayoutX(578.0);
        scoreText.setLayoutY(56.0);
        anchorPane_test.getChildren().add(scoreText);
        
       AnchorPane gp0 = new AnchorPane(backgroundTest, titleLabel, optionBox, anchorPane_test, btHomeTest);
Scene sceneTest = new Scene(gp0, 800, 400);

testButton_S2.setOnAction(e -> {
    stage.setScene(sceneTest);
    stage.show();
});

btHomeTest.setOnAction(e -> {
    stage.setScene(sceneMany);
    stage.show();
});

        
        //----------********Level easy Test******--------------------------
        //-----------------test level easy----------------------
        //-------------------Q1:Hello-----------------
        AnchorPane anchorPane_T1 = new AnchorPane();
        // Set the background image
        // Add ImageView with background image
        ImageView backgroundImageView_T1 = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png"));
        backgroundImageView_T1.setFitHeight(400);
        backgroundImageView_T1.setFitWidth(800);
        anchorPane_T1.getChildren().add(backgroundImageView_T1);

        // Add Text
        Text learnChineseText_T1 = new Text("LearnChinese");
        learnChineseText_T1.setFill(Color.WHITE);
        learnChineseText_T1.setFont(Font.font("Imprint MT Shadow", 38));
        learnChineseText_T1.setLayoutX(120);
        learnChineseText_T1.setLayoutY(59);
        anchorPane_T1.getChildren().add(learnChineseText_T1);

        // Add Rectangle
        Rectangle rectangle_T1 = new Rectangle(320, 215);
        rectangle_T1.setArcWidth(5);
        rectangle_T1.setArcHeight(5);
        rectangle_T1.setFill(Color.web("#db847092"));
        rectangle_T1.setStroke(Color.WHITE);
        rectangle_T1.setStrokeWidth(2);
        rectangle_T1.setLayoutX(233);
        rectangle_T1.setLayoutY(78);
        anchorPane_T1.getChildren().add(rectangle_T1);
        
        Button buttonHome_T1 = new Button();
        buttonHome_T1.setLayoutX(70.0);
        buttonHome_T1.setLayoutY(21.0);
        buttonHome_T1.setMnemonicParsing(false);
        buttonHome_T1.setPrefHeight(53.0);
        buttonHome_T1.setPrefWidth(52.0);
        buttonHome_T1.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
         anchorPane_T1.getChildren().add(buttonHome_T1);
         
         buttonHome_T1.setOnAction(e->{
         stage.setScene(sceneTest);
         stage.show(); 
        });
         
        ImageView HomeImageView_T1 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        HomeImageView_T1.setFitHeight(36);
        HomeImageView_T1.setFitWidth(32);
        HomeImageView_T1.setLayoutX(80);
        HomeImageView_T1.setLayoutY(31);
        anchorPane_T1.getChildren().add(HomeImageView_T1);

        // Add ImageView with "hi" image
        ImageView hiImageView_T1 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//hi//hi.png");
        hiImageView_T1.setFitHeight(150);
        hiImageView_T1.setFitWidth(149);
        hiImageView_T1.setLayoutX(257);
        hiImageView_T1.setLayoutY(103);
        anchorPane_T1.getChildren().add(hiImageView_T1);

        // Add Text
        Text helloText_T1 = new Text("Hello");
        helloText_T1.setFill(Color.rgb(253, 247, 246));
        helloText_T1.setFont(Font.font("Arial", 24));
        helloText_T1.setLayoutX(300);
        helloText_T1.setLayoutY(279);
        anchorPane_T1.getChildren().add(helloText_T1);

// Add Rectangle for score
         Rectangle scoreRectangle_T1 = new Rectangle(173.0, 36.0);
        scoreRectangle_T1.setArcWidth(5.0);
        scoreRectangle_T1.setArcHeight(5.0);
        scoreRectangle_T1.setFill(Color.web("#d98471a3"));
        scoreRectangle_T1.setLayoutX(565.0);
        scoreRectangle_T1.setLayoutY(29.0);
        scoreRectangle_T1.setStroke(Color.WHITE);
        scoreRectangle_T1.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
        scoreRectangle_T1.setStrokeLineJoin(javafx.scene.shape.StrokeLineJoin.ROUND);
        scoreRectangle_T1.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        scoreRectangle_T1.setStrokeWidth(2.0);
        scoreRectangle_T1.setStyle("-fx-stroke-dash-array: 8;");
        anchorPane_T1.getChildren().add(scoreRectangle_T1);

        //score Label
        Label scoreLabel_T1 = new Label();
        scoreLabel_T1.setLayoutX(679.0);
        scoreLabel_T1.setLayoutY(32.0);
        scoreLabel_T1.setTextFill(Color.web("#6d4239"));
        scoreLabel_T1.setFont(Font.font("Imprint MT Shadow", 26.0));
        scoreLabel_T1.setText(Integer.toString(score));
        anchorPane_T1.getChildren().add(scoreLabel_T1);

        //score Text
        Text scoreText_T1 = new Text("Score:");
        scoreText_T1.setFill(Color.web("#52352f"));
        scoreText_T1.setFont(Font.font("Imprint MT Shadow", 26.0));
        scoreText_T1.setLayoutX(578.0);
        scoreText_T1.setLayoutY(56.0);
        anchorPane_T1.getChildren().add(scoreText_T1);

        // Add Buttons for "再见", "你好", "和"
        Button goodbyeButton_T1 = new Button("再见");
        goodbyeButton_T1.setStyle("-fx-background-color: WHITE; -fx-background-radius: 15px; -fx-border-color: darkred; -fx-border-radius: 15px;");
        goodbyeButton_T1.setTextFill(Color.rgb(226, 157, 157));
        goodbyeButton_T1.setFont(Font.font(21));
        goodbyeButton_T1.setLayoutX(430);
        goodbyeButton_T1.setLayoutY(103);
        goodbyeButton_T1.setMaxWidth(91);
        goodbyeButton_T1.setMaxHeight(43);
        anchorPane_T1.getChildren().add(goodbyeButton_T1);
        
        Media wrongmp1_Q1 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//wrong.mp3");  
        MediaPlayer wrong1_Q1 = new MediaPlayer(wrongmp1_Q1); 
        
        goodbyeButton_T1.setOnAction(e ->{  
        wrong1_Q1.stop(); // Stop the media if it's already playing
        wrong1_Q1.play(); // Start playing the media
         }) ; 

        Button helloButton_T1 = new Button("你好");
        helloButton_T1.setStyle("-fx-background-color: WHITE; -fx-background-radius: 15px; -fx-border-color: darkred; -fx-border-radius: 15px;");
        helloButton_T1.setTextFill(Color.rgb(226, 157, 157));
        helloButton_T1.setFont(Font.font(21));
        helloButton_T1.setLayoutX(430);
        helloButton_T1.setLayoutY(163);
        anchorPane_T1.getChildren().add(helloButton_T1);
        
        Media rightmp_Q1 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//right.mp3");  
        MediaPlayer right_Q1 = new MediaPlayer(rightmp_Q1); 
        
        helloButton_T1.setOnAction(e ->{  
        right_Q1.stop(); // Stop the media if it's already playing
        right_Q1.play(); // Start playing the media
         }) ;

        Button andButton_T1 = new Button("和");
        andButton_T1.setStyle("-fx-background-color: WHITE; -fx-background-radius: 15px; -fx-border-color: darkred; -fx-border-radius: 15px;");
        andButton_T1.setTextFill(Color.rgb(226, 157, 157));
        andButton_T1.setFont(Font.font(21));
        andButton_T1.setLayoutX(430);
        andButton_T1.setLayoutY(224);
        anchorPane_T1.getChildren().add(andButton_T1);
        
        Media wrongmp2_Q1 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//wrong.mp3");  
        MediaPlayer wrong2_Q1 = new MediaPlayer(wrongmp2_Q1); 
        
        andButton_T1.setOnAction(e ->{  
        wrong2_Q1.stop(); // Stop the media if it's already playing
        wrong2_Q1.play(); // Start playing the media
         }) ; 

        Button nextButtonT1_Q1 = new Button("Next");
        nextButtonT1_Q1.setLayoutX(558);
        nextButtonT1_Q1.setLayoutY(347);
        nextButtonT1_Q1.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButtonT1_Q1.setTextFill(Color.WHITE);
        nextButtonT1_Q1.setFont(Font.font(18));
        anchorPane_T1.getChildren().add(nextButtonT1_Q1);
        
        // Create the scene
        Scene sceneEasy1 = new Scene(anchorPane_T1, 800, 400);
        button1.setOnAction(e->{
        stage.setScene(sceneEasy1);
        stage.show();
        });
   
        ///////easy test 2/////////
       AnchorPane anchorPane_T2 = new AnchorPane();
        // Set the background image
        // Add ImageView with background image
       ImageView backgroundImageView_T2 = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png"));
        backgroundImageView_T2.setFitHeight(400);
        backgroundImageView_T2.setFitWidth(853);
        anchorPane_T2.getChildren().add(backgroundImageView_T2);

        // Add Text
        Text learnChineseText_T2 = new Text("LearnChinese");
        learnChineseText_T2.setFill(Color.WHITE);
        learnChineseText_T2.setFont(Font.font("Imprint MT Shadow", 38));
        learnChineseText_T2.setLayoutX(120);
        learnChineseText_T2.setLayoutY(59);
        anchorPane_T2.getChildren().add(learnChineseText_T2);

        // Add Rectangle
        Rectangle rectangle_T2 = new Rectangle(320, 215);
        rectangle_T2.setArcWidth(5);
        rectangle_T2.setArcHeight(5);
        rectangle_T2.setFill(Color.web("#db847092"));
        rectangle_T2.setStroke(Color.WHITE);
        rectangle_T2.setStrokeWidth(2);
        rectangle_T2.setLayoutX(233);
        rectangle_T2.setLayoutY(78);
        anchorPane_T2.getChildren().add(rectangle_T2);
        
        
        Button buttonHome_T2 = new Button();
        buttonHome_T2.setLayoutX(70.0);
        buttonHome_T2.setLayoutY(21.0);
        buttonHome_T2.setMnemonicParsing(false);
        buttonHome_T2.setPrefHeight(53.0);
        buttonHome_T2.setPrefWidth(52.0);
        buttonHome_T2.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
         anchorPane_T2.getChildren().add(buttonHome_T2);
         
          buttonHome_T2.setOnAction(e->{
         stage.setScene(sceneTest);
         stage.show(); 
        });
         
        ImageView HomeImageView_T2 = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png"));
        HomeImageView_T2.setFitHeight(36);
        HomeImageView_T2.setFitWidth(32);
        HomeImageView_T2.setLayoutX(80);
        HomeImageView_T2.setLayoutY(31);
        anchorPane_T2.getChildren().add(HomeImageView_T2);

        // Add ImageView with "ok" image
        ImageView OkImageView_T2 = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//ok//okay.png"));
        OkImageView_T2.setFitHeight(150);
        OkImageView_T2.setFitWidth(149);
        OkImageView_T2.setLayoutX(257);
        OkImageView_T2.setLayoutY(103);
        anchorPane_T2.getChildren().add(OkImageView_T2);

        // Add Text
        Text helloText_T2 = new Text("Okay");
        helloText_T2.setFill(Color.rgb(253, 247, 246));
        helloText_T2.setFont(Font.font("Arial", 24));
        helloText_T2.setLayoutX(300);
        helloText_T2.setLayoutY(279);
        anchorPane_T2.getChildren().add(helloText_T2);

        // Add Rectangle for score
         Rectangle scoreRectangle_T2= new Rectangle(173.0, 36.0);
        scoreRectangle_T2.setArcWidth(5.0);
        scoreRectangle_T2.setArcHeight(5.0);
        scoreRectangle_T2.setFill(Color.web("#d98471a3"));
        scoreRectangle_T2.setLayoutX(565.0);
        scoreRectangle_T2.setLayoutY(29.0);
        scoreRectangle_T2.setStroke(Color.WHITE);
        scoreRectangle_T2.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
        scoreRectangle_T2.setStrokeLineJoin(javafx.scene.shape.StrokeLineJoin.ROUND);
        scoreRectangle_T2.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        scoreRectangle_T2.setStrokeWidth(2.0);
        scoreRectangle_T2.setStyle("-fx-stroke-dash-array: 8;");
        anchorPane_T2.getChildren().add(scoreRectangle_T2);

        //score Label
        Label scoreLabel_T2 = new Label();
        scoreLabel_T2.setLayoutX(679.0);
        scoreLabel_T2.setLayoutY(32.0);
        scoreLabel_T2.setTextFill(Color.web("#6d4239"));
        scoreLabel_T2.setFont(Font.font("Imprint MT Shadow", 26.0));
        scoreLabel_T2.setText(Integer.toString(score));
        anchorPane_T2.getChildren().add(scoreLabel_T2);
        
        //score Text
        Text scoreText_T2 = new Text("Score:");
        scoreText_T2.setFill(Color.web("#52352f"));
        scoreText_T2.setFont(Font.font("Imprint MT Shadow", 26.0));
        scoreText_T2.setLayoutX(578.0);
        scoreText_T2.setLayoutY(56.0);
        anchorPane_T2.getChildren().add(scoreText_T2);

        // Add Buttons for "再见", "你好", "和"
        //wrong
        Button FirstButton_T2 = new Button("或");
        FirstButton_T2.setStyle("-fx-background-color: WHITE; -fx-background-radius: 15px; -fx-border-color: darkred; -fx-border-radius: 15px;");
        FirstButton_T2.setTextFill(Color.rgb(226, 157, 157));
        FirstButton_T2.setFont(Font.font(21));
        FirstButton_T2.setLayoutX(430);
        FirstButton_T2.setLayoutY(103);
        FirstButton_T2.setMaxWidth(91);
        FirstButton_T2.setMaxHeight(43);
        anchorPane_T2.getChildren().add(FirstButton_T2);
        
        Media wrongmp1_Q2 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//wrong.mp3");  
        MediaPlayer wrong1_Q2 = new MediaPlayer(wrongmp1_Q2); 
        
        FirstButton_T2.setOnAction(e ->{  
        wrong1_Q2.stop(); // Stop the media if it's already playing
        wrong1_Q2.play(); // Start playing the media
         }) ; 

        //wrong
        Button SecoundButton_T2 = new Button("你好");
        SecoundButton_T2.setStyle("-fx-background-color: WHITE; -fx-background-radius: 15px; -fx-border-color: darkred; -fx-border-radius: 15px;");
        SecoundButton_T2.setTextFill(Color.rgb(226, 157, 157));
        SecoundButton_T2.setFont(Font.font(21));
        SecoundButton_T2.setLayoutX(430);
        SecoundButton_T2.setLayoutY(163);
        anchorPane_T2.getChildren().add(SecoundButton_T2);
        
        Media wrongmp2_Q2 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//wrong.mp3");  
        MediaPlayer wrong2_Q2 = new MediaPlayer(wrongmp2_Q2); 
        
        SecoundButton_T2.setOnAction(e ->{  
        wrong2_Q2.stop(); // Stop the media if it's already playing
        wrong2_Q2.play(); // Start playing the media
        
         }) ; 

        //right
        Button ThirdButton_T2 = new Button("好");
        ThirdButton_T2.setStyle("-fx-background-color: WHITE; -fx-background-radius: 15px; -fx-border-color: darkred; -fx-border-radius: 15px;");
        ThirdButton_T2.setTextFill(Color.rgb(226, 157, 157));
        ThirdButton_T2.setFont(Font.font(21));
        ThirdButton_T2.setLayoutX(430);
        ThirdButton_T2.setLayoutY(224);
        anchorPane_T2.getChildren().add(ThirdButton_T2);
        
        Media rightmp_Q2 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//right.mp3");  
        MediaPlayer right_Q2 = new MediaPlayer(rightmp_Q2); 
        
        ThirdButton_T2.setOnAction(e ->{  
        right_Q2.stop(); // Stop the media if it's already playing
        right_Q2.play(); // Start playing the media
        
         }) ;
        
        Button nextButtonT1_Q2 = new Button("Next");
        nextButtonT1_Q2.setLayoutX(558);
        nextButtonT1_Q2.setLayoutY(347);
        nextButtonT1_Q2.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButtonT1_Q2.setTextFill(Color.WHITE);
        nextButtonT1_Q2.setFont(Font.font(18));
        anchorPane_T2.getChildren().add(nextButtonT1_Q2);
                // Create the scene
        Scene sceneEasy2 = new Scene(anchorPane_T2, 800, 400);
        nextButtonT1_Q1.setOnAction(e->{
            stage.setScene(sceneEasy2);
            stage.show();
        });
        
        ////////***easy test 3***///////      
        AnchorPane anchorPane_T3 = new AnchorPane();
        // Set the background image
        // Add ImageView with background image
       ImageView backgroundImageView_T3 = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png"));
        backgroundImageView_T3.setFitHeight(400);
        backgroundImageView_T3.setFitWidth(853);
        anchorPane_T3.getChildren().add(backgroundImageView_T3);

        // Add Text
        Text learnChineseText_T3 = new Text("LearnChinese");
        learnChineseText_T3.setFill(Color.WHITE);
        learnChineseText_T3.setFont(Font.font("Imprint MT Shadow", 38));
        learnChineseText_T3.setLayoutX(120);
        learnChineseText_T3.setLayoutY(59);
        anchorPane_T3.getChildren().add(learnChineseText_T3);

        Rectangle rectangle_T3 = new Rectangle(320, 215);
        rectangle_T3.setArcWidth(5);
        rectangle_T3.setArcHeight(5);
        rectangle_T3.setFill(Color.web("#db847092"));
        rectangle_T3.setStroke(Color.WHITE);
        rectangle_T3.setStrokeWidth(2);
        rectangle_T3.setLayoutX(233);
        rectangle_T3.setLayoutY(78);
        anchorPane_T3.getChildren().add(rectangle_T3);

        Button buttonHome_T3 = new Button();
        buttonHome_T3.setLayoutX(70.0);
        buttonHome_T3.setLayoutY(21.0);
        buttonHome_T3.setMnemonicParsing(false);
        buttonHome_T3.setPrefHeight(53.0);
        buttonHome_T3.setPrefWidth(52.0);
        buttonHome_T3.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
         anchorPane_T3.getChildren().add(buttonHome_T3);
         
          buttonHome_T3.setOnAction(e->{
         stage.setScene(sceneTest);
         stage.show(); 
        });
         
        // Add ImageView with "home" image
        ImageView HomeImageView_T3 = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png"));
        HomeImageView_T3.setFitHeight(36);
        HomeImageView_T3.setFitWidth(32);
        HomeImageView_T3.setLayoutX(80);
        HomeImageView_T3.setLayoutY(31);
        anchorPane_T3.getChildren().add(HomeImageView_T3);

        // Add ImageView with "thanks" image
        ImageView thanksImageView_T3 = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//thanks//thanks.png"));
        thanksImageView_T3.setFitHeight(150);
        thanksImageView_T3.setFitWidth(149);
        thanksImageView_T3.setLayoutX(257);
        thanksImageView_T3.setLayoutY(103);
        anchorPane_T3.getChildren().add(thanksImageView_T3);

        // Add Text
        Text thanksText_T3 = new Text("Thank you");
        thanksText_T3.setFill(Color.rgb(253, 247, 246));
        thanksText_T3.setFont(Font.font("Arial", 24));
        thanksText_T3.setLayoutX(300);
        thanksText_T3.setLayoutY(279);
        anchorPane_T3.getChildren().add(thanksText_T3);

// Add Rectangle for score
        Rectangle scoreRectangle_T3 = new Rectangle(173.0, 36.0);
        scoreRectangle_T3.setArcWidth(5.0);
        scoreRectangle_T3.setArcHeight(5.0);
        scoreRectangle_T3.setFill(Color.web("#d98471a3"));
        scoreRectangle_T3.setLayoutX(565.0);
        scoreRectangle_T3.setLayoutY(29.0);
        scoreRectangle_T3.setStroke(Color.WHITE);
        scoreRectangle_T3.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
        scoreRectangle_T3.setStrokeLineJoin(javafx.scene.shape.StrokeLineJoin.ROUND);
        scoreRectangle_T3.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        scoreRectangle_T3.setStrokeWidth(2.0);
        scoreRectangle_T3.setStyle("-fx-stroke-dash-array: 8;");
        anchorPane_T3.getChildren().add(scoreRectangle_T3);

        //score Label
        Label scoreLabel_T3 = new Label();
        scoreLabel_T3.setLayoutX(679.0);
        scoreLabel_T3.setLayoutY(32.0);
        scoreLabel_T3.setTextFill(Color.web("#6d4239"));
        scoreLabel_T3.setFont(Font.font("Imprint MT Shadow", 26.0));
        scoreLabel_T3.setText(Integer.toString(score));
        anchorPane_T3.getChildren().add(scoreLabel_T3);
        
        //score Text
        Text scoreText_T3 = new Text("Score:");
        scoreText_T3.setFill(Color.web("#52352f"));
        scoreText_T3.setFont(Font.font("Imprint MT Shadow", 26.0));
        scoreText_T3.setLayoutX(578.0);
        scoreText_T3.setLayoutY(56.0);
        anchorPane_T3.getChildren().add(scoreText_T3);

        // Add Buttons for "再见", "你好", "和"
        //right
        Button FirstButton_T3 = new Button("谢谢");
        FirstButton_T3.setStyle("-fx-background-color: WHITE; -fx-background-radius: 15px; -fx-border-color: darkred; -fx-border-radius: 15px;");
        FirstButton_T3.setTextFill(Color.rgb(226, 157, 157));
        FirstButton_T3.setFont(Font.font(21));
        FirstButton_T3.setLayoutX(430);
        FirstButton_T3.setLayoutY(103);
        FirstButton_T3.setMaxWidth(91);
        FirstButton_T3.setMaxHeight(43);
        anchorPane_T3.getChildren().add(FirstButton_T3);
        
        Media rightmp_Q3 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//right.mp3");  
        MediaPlayer right_Q3 = new MediaPlayer(rightmp_Q3); 
        
        FirstButton_T3.setOnAction(e ->{  
        right_Q3.stop(); // Stop the media if it's already playing
        right_Q3.play(); // Start playing the media
         }) ;

        //wrong
        Button SecoundButton_T3 = new Button("这");
        SecoundButton_T3.setStyle("-fx-background-color: WHITE; -fx-background-radius: 15px; -fx-border-color: darkred; -fx-border-radius: 15px;");
        SecoundButton_T3.setTextFill(Color.rgb(226, 157, 157));
        SecoundButton_T3.setFont(Font.font(21));
        SecoundButton_T3.setLayoutX(430);
        SecoundButton_T3.setLayoutY(163);
        anchorPane_T3.getChildren().add(SecoundButton_T3);
        
        Media wrongmp1_Q3 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//wrong.mp3");  
        MediaPlayer wrong1_Q3 = new MediaPlayer(wrongmp1_Q3); 
        
        SecoundButton_T3.setOnAction(e ->{  
        wrong1_Q3.stop(); // Stop the media if it's already playing
        wrong1_Q3.play(); // Start playing the media
         }) ; 

        //wrong
        Button ThirdButton_T3 = new Button("好");
        ThirdButton_T3.setStyle("-fx-background-color: WHITE; -fx-background-radius: 15px; -fx-border-color: darkred; -fx-border-radius: 15px;");
        ThirdButton_T3.setTextFill(Color.rgb(226, 157, 157));
        ThirdButton_T3.setFont(Font.font(21));
        ThirdButton_T3.setLayoutX(430);
        ThirdButton_T3.setLayoutY(224);
        anchorPane_T3.getChildren().add(ThirdButton_T3);
        
        Media wrongmp2_Q3 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//wrong.mp3");  
        MediaPlayer wrong2_Q3 = new MediaPlayer(wrongmp2_Q3); 
        
        ThirdButton_T3.setOnAction(e ->{  
        wrong2_Q3.stop(); // Stop the media if it's already playing
        wrong2_Q3.play(); // Start playing the media
         }) ; 
        Button nextButtonT1_Q3 = new Button("Next");
        nextButtonT1_Q3.setLayoutX(558);
        nextButtonT1_Q3.setLayoutY(347);
        nextButtonT1_Q3.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButtonT1_Q3.setTextFill(Color.WHITE);
        nextButtonT1_Q3.setFont(Font.font(18));
        anchorPane_T3.getChildren().add(nextButtonT1_Q3);
        // Create the scene
        Scene sceneEasy3 = new Scene(anchorPane_T3, 800, 400);
        nextButtonT1_Q2.setOnAction(e->{
            stage.setScene(sceneEasy3);
            stage.show();
        });
        
        ////////***easy test 4***///////
        
        AnchorPane anchorPane_T4 = new AnchorPane();
        // Set the background image
        // Add ImageView with background image
       ImageView backgroundImageView_T4 = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png"));
        backgroundImageView_T4.setFitHeight(400);
        backgroundImageView_T4.setFitWidth(853);
        anchorPane_T4.getChildren().add(backgroundImageView_T4);

        // Add Text
        Text learnChineseText_T4 = new Text("LearnChinese");
        learnChineseText_T4.setFill(Color.WHITE);
        learnChineseText_T4.setFont(Font.font("Imprint MT Shadow", 38));
        learnChineseText_T4.setLayoutX(120);
        learnChineseText_T4.setLayoutY(59);
        anchorPane_T4.getChildren().add(learnChineseText_T4);

      
        // Add Rectangle
        Rectangle rectangle_T4 = new Rectangle(320, 215);
        rectangle_T4.setArcWidth(5);
        rectangle_T4.setArcHeight(5);
        rectangle_T4.setFill(Color.web("#db847092"));
        rectangle_T4.setStroke(Color.WHITE);
        rectangle_T4.setStrokeWidth(2);
        rectangle_T4.setLayoutX(233);
        rectangle_T4.setLayoutY(78);
        anchorPane_T4.getChildren().add(rectangle_T4);
        
        
        Button buttonHome_T4 = new Button();
        buttonHome_T4.setLayoutX(70.0);
        buttonHome_T4.setLayoutY(21.0);
        buttonHome_T4.setMnemonicParsing(false);
        buttonHome_T4.setPrefHeight(53.0);
        buttonHome_T4.setPrefWidth(52.0);
        buttonHome_T4.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
         anchorPane_T4.getChildren().add(buttonHome_T4);
         
          buttonHome_T4.setOnAction(e->{
         stage.setScene(sceneTest);
         stage.show(); 
        });
         
        // Add ImageView with "home" image
        ImageView HomeImageView_T4 = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png"));
        HomeImageView_T4.setFitHeight(36);
        HomeImageView_T4.setFitWidth(32);
        HomeImageView_T4.setLayoutX(80);
        HomeImageView_T4.setLayoutY(31);
        anchorPane_T4.getChildren().add(HomeImageView_T4);

      
        // Add ImageView with "please" image
        ImageView pleaseImageView_T4 = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//please//please.png"));
        pleaseImageView_T4.setFitHeight(150);
        pleaseImageView_T4.setFitWidth(149);
        pleaseImageView_T4.setLayoutX(257);
        pleaseImageView_T4.setLayoutY(103);
        anchorPane_T4.getChildren().add(pleaseImageView_T4);

        // Add Text
        Text pleaseText_T4 = new Text("Please");
        pleaseText_T4.setFill(Color.rgb(253, 247, 246));
        pleaseText_T4.setFont(Font.font("Arial", 24));
        pleaseText_T4.setLayoutX(300);
        pleaseText_T4.setLayoutY(279);
        anchorPane_T4.getChildren().add(pleaseText_T4);

// Add Rectangle for score
         Rectangle scoreRectangle_T4 = new Rectangle(173.0, 36.0);
        scoreRectangle_T4.setArcWidth(5.0);
        scoreRectangle_T4.setArcHeight(5.0);
        scoreRectangle_T4.setFill(Color.web("#d98471a3"));
        scoreRectangle_T4.setLayoutX(565.0);
        scoreRectangle_T4.setLayoutY(29.0);
        scoreRectangle_T4.setStroke(Color.WHITE);
        scoreRectangle_T4.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
        scoreRectangle_T4.setStrokeLineJoin(javafx.scene.shape.StrokeLineJoin.ROUND);
        scoreRectangle_T4.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        scoreRectangle_T4.setStrokeWidth(2.0);
        scoreRectangle_T4.setStyle("-fx-stroke-dash-array: 8;");
        anchorPane_T4.getChildren().add(scoreRectangle_T4);

        //score Label
        Label scoreLabel_T4 = new Label();
        scoreLabel_T4.setLayoutX(679.0);
        scoreLabel_T4.setLayoutY(32.0);
        scoreLabel_T4.setTextFill(Color.web("#6d4239"));
        scoreLabel_T4.setFont(Font.font("Imprint MT Shadow", 26.0));
        scoreLabel_T4.setText(Integer.toString(score));
        anchorPane_T4.getChildren().add(scoreLabel_T4);
        

        //score Text
        Text scoreText_T4 = new Text("Score:");
        scoreText_T4.setFill(Color.web("#52352f"));
        scoreText_T4.setFont(Font.font("Imprint MT Shadow", 26.0));
        scoreText_T4.setLayoutX(578.0);
        scoreText_T4.setLayoutY(56.0);
        anchorPane_T4.getChildren().add(scoreText_T4);
        // Add Buttons for "再见", "你好", "和"
        //wrong
        Button FirstButton_T4 = new Button("再见");
        FirstButton_T4.setStyle("-fx-background-color: WHITE; -fx-background-radius: 15px; -fx-border-color: darkred; -fx-border-radius: 15px;");
        FirstButton_T4.setTextFill(Color.rgb(226, 157, 157));
        FirstButton_T4.setFont(Font.font(21));
        FirstButton_T4.setLayoutX(430);
        FirstButton_T4.setLayoutY(103);
        FirstButton_T4.setMaxWidth(91);
        FirstButton_T4.setMaxHeight(43);
        anchorPane_T4.getChildren().add(FirstButton_T4);
        
        Media wrongmp1_Q4 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//wrong.mp3");  
        MediaPlayer wrong1_Q4 = new MediaPlayer(wrongmp1_Q4); 
        
        FirstButton_T4.setOnAction(e ->{  
        wrong1_Q4.stop(); // Stop the media if it's already playing
        wrong1_Q4.play(); // Start playing the media
         }) ; 
       
        //right
        Button SecoundButton_T4 = new Button("请");
        SecoundButton_T4.setStyle("-fx-background-color: WHITE; -fx-background-radius: 15px; -fx-border-color: darkred; -fx-border-radius: 15px;");
        SecoundButton_T4.setTextFill(Color.rgb(226, 157, 157));
        SecoundButton_T4.setFont(Font.font(21));
        SecoundButton_T4.setLayoutX(430);
        SecoundButton_T4.setLayoutY(163);
        anchorPane_T4.getChildren().add(SecoundButton_T4);
        
        Media rightmp_Q4 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//right.mp3");  
        MediaPlayer right_Q4 = new MediaPlayer(rightmp_Q4); 
        
        SecoundButton_T4.setOnAction(e ->{  
        right_Q4.stop(); // Stop the media if it's already playing
        right_Q4.play(); // Start playing the media
         }) ;
       

        //wrong
        Button ThirdButton_T4 = new Button("好");
        ThirdButton_T4.setStyle("-fx-background-color: WHITE; -fx-background-radius: 15px; -fx-border-color: darkred; -fx-border-radius: 15px;");
        ThirdButton_T4.setTextFill(Color.rgb(226, 157, 157));
        ThirdButton_T4.setFont(Font.font(21));
        ThirdButton_T4.setLayoutX(430);
        ThirdButton_T4.setLayoutY(224);
        anchorPane_T4.getChildren().add(ThirdButton_T4);
        
        Media wrongmp2_Q4 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//wrong.mp3");  
        MediaPlayer wrong2_Q4 = new MediaPlayer(wrongmp2_Q4); 
        
        ThirdButton_T4.setOnAction(e ->{  
        wrong2_Q4.stop(); // Stop the media if it's already playing
        wrong2_Q4.play(); // Start playing the media
         }) ; 
        Button nextButtonT1_Q4 = new Button("Next");
        nextButtonT1_Q4.setLayoutX(558);
        nextButtonT1_Q4.setLayoutY(347);
        nextButtonT1_Q4.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButtonT1_Q4.setTextFill(Color.WHITE);
        nextButtonT1_Q4.setFont(Font.font(18));
        anchorPane_T4.getChildren().add(nextButtonT1_Q4);
        

        // Create the scene
        Scene sceneEasy4 = new Scene(anchorPane_T4, 800, 400);
        nextButtonT1_Q3.setOnAction(e->{
            stage.setScene(sceneEasy4);
            stage.show();
        });
        
        ////////***easy test 5***///////
        
        AnchorPane anchorPane_T5 = new AnchorPane();
        // Set the background image
        // Add ImageView with background image
       ImageView backgroundImageView_T5 = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png"));
        backgroundImageView_T5.setFitHeight(400);
        backgroundImageView_T5.setFitWidth(853);
        anchorPane_T5.getChildren().add(backgroundImageView_T5);

        // Add Text
        Text learnChineseText_T5 = new Text("LearnChinese");
        learnChineseText_T5.setFill(Color.WHITE);
        learnChineseText_T5.setFont(Font.font("Imprint MT Shadow", 38));
        learnChineseText_T5.setLayoutX(120);
        learnChineseText_T5.setLayoutY(59);
        anchorPane_T5.getChildren().add(learnChineseText_T5);

      

        // Add Rectangle
        Rectangle rectangle_T5 = new Rectangle(320, 215);
        rectangle_T5.setArcWidth(5);
        rectangle_T5.setArcHeight(5);
        rectangle_T5.setFill(Color.web("#db847092"));
        rectangle_T5.setStroke(Color.WHITE);
        rectangle_T5.setStrokeWidth(2);
        rectangle_T5.setLayoutX(233);
        rectangle_T5.setLayoutY(78);
        anchorPane_T5.getChildren().add(rectangle_T5);
        
        
        Button buttonHome_T5 = new Button();
        buttonHome_T5.setLayoutX(70.0);
        buttonHome_T5.setLayoutY(21.0);
        buttonHome_T5.setMnemonicParsing(false);
        buttonHome_T5.setPrefHeight(53.0);
        buttonHome_T5.setPrefWidth(52.0);
        buttonHome_T5.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
         anchorPane_T5.getChildren().add(buttonHome_T5);
         
          buttonHome_T5.setOnAction(e->{
         stage.setScene(sceneTest);
         stage.show(); 
        });
         
        // Add ImageView with "home" image
        ImageView HomeImageView_T5 = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png"));
        HomeImageView_T5.setFitHeight(36);
        HomeImageView_T5.setFitWidth(32);
        HomeImageView_T5.setLayoutX(80);
        HomeImageView_T5.setLayoutY(31);
        anchorPane_T5.getChildren().add(HomeImageView_T5);

        // Add ImageView with "small" image
        ImageView smallImageView_T5 = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//small//small.png"));
        smallImageView_T5.setFitHeight(150);
        smallImageView_T5.setFitWidth(149);
        smallImageView_T5.setLayoutX(257);
        smallImageView_T5.setLayoutY(103);
        anchorPane_T5.getChildren().add(smallImageView_T5);

        // Add Text
        Text smallText_T5 = new Text("Small");
        smallText_T5.setFill(Color.rgb(253, 247, 246));
        smallText_T5.setFont(Font.font("Arial", 24));
        smallText_T5.setLayoutX(300);
        smallText_T5.setLayoutY(279);
        anchorPane_T5.getChildren().add(smallText_T5);

    // Add Rectangle for score
         Rectangle scoreRectangle_T5 = new Rectangle(173.0, 36.0);
        scoreRectangle_T5.setArcWidth(5.0);
        scoreRectangle_T5.setArcHeight(5.0);
        scoreRectangle_T5.setFill(Color.web("#d98471a3"));
        scoreRectangle_T5.setLayoutX(565.0);
        scoreRectangle_T5.setLayoutY(29.0);
        scoreRectangle_T5.setStroke(Color.WHITE);
        scoreRectangle_T5.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
        scoreRectangle_T5.setStrokeLineJoin(javafx.scene.shape.StrokeLineJoin.ROUND);
        scoreRectangle_T5.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        scoreRectangle_T5.setStrokeWidth(2.0);
        scoreRectangle_T5.setStyle("-fx-stroke-dash-array: 8;");
        anchorPane_T5.getChildren().add(scoreRectangle_T5);

        //score Label
        Label scoreLabel_T5 = new Label();
        scoreLabel_T5.setLayoutX(679.0);
        scoreLabel_T5.setLayoutY(32.0);
        scoreLabel_T5.setTextFill(Color.web("#6d4239"));
        scoreLabel_T5.setFont(Font.font("Imprint MT Shadow", 26.0));
        scoreLabel_T5.setText(Integer.toString(score));
        anchorPane_T5.getChildren().add(scoreLabel_T5);
        

        //score Text
        Text scoreText_T5 = new Text("Score:");
        scoreText_T5.setFill(Color.web("#52352f"));
        scoreText_T5.setFont(Font.font("Imprint MT Shadow", 26.0));
        scoreText_T5.setLayoutX(578.0);
        scoreText_T5.setLayoutY(56.0);
        anchorPane_T5.getChildren().add(scoreText_T5);

        // Add Buttons for "再见", "你好", "和"
        //wrong
        Button FirstButton_T5 = new Button("大");
        FirstButton_T5.setStyle("-fx-background-color: WHITE; -fx-background-radius: 15px; -fx-border-color: darkred; -fx-border-radius: 15px;");
        FirstButton_T5.setTextFill(Color.rgb(226, 157, 157));
        FirstButton_T5.setFont(Font.font(21));
        FirstButton_T5.setLayoutX(430);
        FirstButton_T5.setLayoutY(103);
        FirstButton_T5.setMaxWidth(91);
        FirstButton_T5.setMaxHeight(43);
        anchorPane_T5.getChildren().add(FirstButton_T5);
        
        Media wrongmp1_Q5 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//wrong.mp3");  
        MediaPlayer wrong1_Q5 = new MediaPlayer(wrongmp1_Q5); 
        
        FirstButton_T5.setOnAction(e ->{  
        wrong1_Q5.stop(); // Stop the media if it's already playing
        wrong1_Q5.play(); // Start playing the media
         }) ; 
    
        //wrong
        Button SecoundButton_T5 = new Button("请");
        SecoundButton_T5.setStyle("-fx-background-color: WHITE; -fx-background-radius: 15px; -fx-border-color: darkred; -fx-border-radius: 15px;");
        SecoundButton_T5.setTextFill(Color.rgb(226, 157, 157));
        SecoundButton_T5.setFont(Font.font(21));
        SecoundButton_T5.setLayoutX(430);
        SecoundButton_T5.setLayoutY(163);
        anchorPane_T5.getChildren().add(SecoundButton_T5);
        
        Media wrongmp2_Q5 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//wrong.mp3");  
        MediaPlayer wrong2_Q5 = new MediaPlayer(wrongmp2_Q5); 
        
        SecoundButton_T5.setOnAction(e ->{  
        wrong2_Q5.stop(); // Stop the media if it's already playing
        wrong2_Q5.play(); // Start playing the media
         }) ;
       

        //right
        Button ThirdButton_T5 = new Button("小");
        ThirdButton_T5.setStyle("-fx-background-color: WHITE; -fx-background-radius: 15px; -fx-border-color: darkred; -fx-border-radius: 15px;");
        ThirdButton_T5.setTextFill(Color.rgb(226, 157, 157));
        ThirdButton_T5.setFont(Font.font(21));
        ThirdButton_T5.setLayoutX(430);
        ThirdButton_T5.setLayoutY(224);
        anchorPane_T5.getChildren().add(ThirdButton_T5);
        
        Media rightmp_Q5 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//right.mp3");  
        MediaPlayer right_Q5 = new MediaPlayer(rightmp_Q5); 
        
        ThirdButton_T5.setOnAction(e ->{  
        right_Q5.stop(); // Stop the media if it's already playing
        right_Q5.play(); // Start playing the media
         }) ; 
        Button nextButtonT1_Q5 = new Button("Next");
        nextButtonT1_Q5.setLayoutX(558);
        nextButtonT1_Q5.setLayoutY(347);
        nextButtonT1_Q5.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButtonT1_Q5.setTextFill(Color.WHITE);
        nextButtonT1_Q5.setFont(Font.font(18));
        anchorPane_T5.getChildren().add(nextButtonT1_Q5);

        // Create the scene
        Scene sceneEasy5 = new Scene(anchorPane_T5, 800, 400);
        nextButtonT1_Q4.setOnAction(e->{
            stage.setScene(sceneEasy5);
            stage.show();
        });
        nextButtonT1_Q5.setOnAction(e->{
            stage.setScene(sceneTest);
            stage.show();
        });
        
    //--------------test level middle--------------------
             //-------------------Q1:Hello-----------------
        AnchorPane anchorPaneHello = new AnchorPane();
        ImageView imagetest1 = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png"));
        imagetest1.setFitWidth(800.0);
        imagetest1.setPreserveRatio(true);

        Button trueButton = new Button("True");
        trueButton.setLayoutX(200.0);
        trueButton.setLayoutY(260.0);
        trueButton.setMnemonicParsing(false);
        trueButton.setPrefHeight(51.0);
        trueButton.setPrefWidth(140.0);
        trueButton.setStyle("-fx-background-color: #41774a; -fx-background-radius: 20px;");
        trueButton.setTextAlignment(TextAlignment.CENTER);
        trueButton.setTextFill(Color.WHITE);
        trueButton.setFont(Font.font("Times new roman", FontWeight.BOLD, 25));
        
        Button falseButton = new Button("False");
        falseButton.setLayoutX(430.0);
        falseButton.setLayoutY(260.0);
        falseButton.setMnemonicParsing(false);
        falseButton.setPrefHeight(51.0);
        falseButton.setPrefWidth(140.0);
        falseButton.setStyle("-fx-background-color: #ba2222; -fx-background-radius: 20px;");
        falseButton.setTextAlignment(TextAlignment.CENTER);
        falseButton.setTextFill(Color.WHITE);
        falseButton.setFont(Font.font("Times new roman", FontWeight.BOLD, 25));

        Text learnChineseText = new Text("Learn Chinese");
        learnChineseText.setFill(Color.WHITE); // Change color to white
        learnChineseText.setFont(Font.font("Times new roman", FontWeight.BOLD,FontPosture.ITALIC, 38)); // Change font
        learnChineseText.setStyle("-fx-stroke: #992725;"+"-fx-stroke-width: 1;");
        learnChineseText.setLayoutX(140);
        learnChineseText.setLayoutY(59);
        learnChineseText.setTextAlignment(TextAlignment.CENTER);

        Text clickTText = new Text("Click on the \"T\" Key if this is the correct word");
        clickTText.setFill(Color.web("#41774a"));
        clickTText.setLayoutX(200.0);
        clickTText.setLayoutY(350.0);
        clickTText.setStrokeType(StrokeType.OUTSIDE);
        clickTText.setFont(Font.font("Times new roman", FontWeight.BOLD, 18));
        
        Text clickFText = new Text("Click on the \"F\" Key if it is incorrect");
        clickFText.setFill(Color.web("#9f2424"));
        clickFText.setLayoutX(200.0);
        clickFText.setLayoutY(380.0);
        clickFText.setStrokeType(StrokeType.OUTSIDE);
        clickFText.setFont(Font.font("Times new roman", FontWeight.BOLD, 18));
        
        Text helloText = new Text("Hello");
        helloText.setFill(Color.WHITE);
        helloText.setLayoutX(255.0);
        helloText.setLayoutY(198.0);
        helloText.setStrokeType(StrokeType.OUTSIDE);
        helloText.setStroke(Color.web("#992725"));
        helloText.setFont(Font.font("Times New Roman", 48.0));
        
        Button btHomeM0 = new Button();
        btHomeM0.setLayoutX(50.0);
        btHomeM0.setLayoutY(21.0);
        btHomeM0.setMnemonicParsing(false);
        btHomeM0.setPrefHeight(53.0);
        btHomeM0.setPrefWidth(52.0);
        btHomeM0.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView HomeiconT1 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        HomeiconT1.setFitHeight(36.0);
        HomeiconT1.setFitWidth(32.0);
        HomeiconT1.setPreserveRatio(true);
        btHomeM0.setGraphic(HomeiconT1);
       btHomeM0.setOnAction(e->{
            stage.setScene(sceneTest);
           stage.show();
            });
        Button audioTestW1 = new Button();
        audioTestW1.setLayoutX(420);
        audioTestW1.setLayoutY(155);
        audioTestW1.setPrefHeight(53);
        audioTestW1.setPrefWidth(52);
        ImageView audioTestImage1 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//audio.png");
        audioTestImage1.setFitHeight(55);
        audioTestImage1.setFitWidth(50);
        audioTestImage1.setLayoutX(476);
        audioTestImage1.setLayoutY(176);
        audioTestW1.setGraphic(audioTestImage1);
        audioTestW1.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        
        Media himp = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//hi//hi.mp3");  
        MediaPlayer hiTest = new MediaPlayer(himp); 
        audioTestW1.setOnAction(e ->{  
        hiTest.stop(); // Stop the media if it's already playing
        hiTest.play(); // Start playing the media
         }) ; 
        
         Pane ScoreBoxhi = new Pane();
        // Rectangle
        Rectangle rectangle00 = new Rectangle(173.0, 36.0);
        rectangle00.setArcWidth(5.0);
        rectangle00.setArcHeight(5.0);
        rectangle00.setFill(Color.web("#d98471a3"));
        rectangle00.setLayoutX(565.0);
        rectangle00.setLayoutY(29.0);
        rectangle00.setStroke(Color.WHITE);
        rectangle00.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
        rectangle00.setStrokeLineJoin(javafx.scene.shape.StrokeLineJoin.ROUND);
        rectangle00.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        rectangle00.setStrokeWidth(2.0);
        rectangle00.setStyle("-fx-stroke-dash-array: 8;");

        // Label
        Label label = new Label(Integer.toString(score));
        label.setLayoutX(679.0);
        label.setLayoutY(32.0);
        label.setTextFill(Color.web("#6d4239"));
        label.setFont(Font.font("Imprint MT Shadow", 26.0));

        // Text
        Text textScore = new Text("Score:");
        textScore.setFill(Color.web("#52352f"));
        textScore.setFont(Font.font("Imprint MT Shadow", 26.0));
        textScore.setLayoutX(578.0);
        textScore.setLayoutY(56.0);

        ScoreBoxhi.getChildren().addAll(btHomeM0,rectangle00, label, textScore);
        Button nextButtonM0 = new Button("Next");
        nextButtonM0.setLayoutX(558);
        nextButtonM0.setLayoutY(347);
        nextButtonM0.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButtonM0.setTextFill(Color.WHITE);
        nextButtonM0.setFont(Font.font(18));
        
        Media rightmp_M1 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//right.mp3");  
        MediaPlayer right_M1 = new MediaPlayer(rightmp_M1); 
   
        Media wrongmp_M1 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//wrong.mp3");  
        MediaPlayer wrong_M1 = new MediaPlayer(wrongmp_M1);
        
        falseButton.setOnAction(e->{
        wrong_M1.play();
        wrong_M1.stop();
        });
         
        anchorPaneHello.getChildren().addAll(imagetest1,audioTestW1,nextButtonM0,
                trueButton, falseButton, learnChineseText, clickTText, clickFText, helloText,ScoreBoxhi);

        Scene sceneTestHello = new Scene(anchorPaneHello, 800, 400);
        
        
       button2.setOnAction(e->{
            if(score>=10){
         stage.setScene(sceneTestHello);
        stage.setTitle("Test Level Middle");
        stage.show(); }
            else{
                BorderPane successBorderPane= new BorderPane();
       Rectangle successRect = new Rectangle(400, 50); // Adjust the dimensions as needed
    successRect.setFill(Color.rgb(220, 131, 111, 0.57));
    successRect.setLayoutX(200);
    successRect.setLayoutY(200);
    successRect.setStroke(Color.WHITE);
            successRect.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
            successRect.setStrokeLineJoin(javafx.scene.shape.StrokeLineJoin.ROUND);
            successRect.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
            successRect.setStrokeWidth(2.0);
            successRect.setStyle("-fx-stroke-dash-array: 8;");

    Text successText = new Text("You have to get 10 score");
    successText.setFill(Color.WHITE);
    successText.setFont(Font.font("Helvetica", FontWeight.BOLD, 20));
    successText.setLayoutX(295);
    successText.setLayoutY(230);

    Image backgroundImage3 = new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
    ImageView imageView = new ImageView(backgroundImage3);
    imageView.setFitWidth(800); // Set the width of the image view
    imageView.setFitHeight(400); // Set the height of the image view

    Pane combinedPane = new Pane();
    combinedPane.getChildren().addAll(imageView, successRect, successText);
    successBorderPane.getChildren().add(combinedPane);

    Scene successScene = new Scene(successBorderPane, 800, 400);
    stage.setScene(successScene);
    stage.show();

            // Set up a timeline to remove the success message after a certain duration
            Duration displayDuration = Duration.seconds(1); // Adjust the duration as needed
            Timeline timeline = new Timeline(new KeyFrame(displayDuration, event -> {
                // Remove the success message
                stage.setScene(sceneTest); // Set the scene back to the login scene
                stage.show();
            }));
            timeline.play();
        }
    });
       
     
 //-------------------Q2:Goodbye-----------------
        AnchorPane anchorPaneGoodbye = new AnchorPane();

        ImageView backgroundImage = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png"));
        backgroundImage.setFitWidth(800.0);
        backgroundImage.setPreserveRatio(true);

        Button trueButtonGoodbye = new Button("True");
        trueButtonGoodbye.setLayoutX(200.0);
        trueButtonGoodbye.setLayoutY(260.0);
        trueButtonGoodbye.setMnemonicParsing(false);
        trueButtonGoodbye.setPrefHeight(51.0);
        trueButtonGoodbye.setPrefWidth(140.0);
        trueButtonGoodbye.setStyle("-fx-background-color: #41774a; -fx-background-radius: 20px;");
        trueButtonGoodbye.setTextAlignment(TextAlignment.CENTER);
        trueButtonGoodbye.setTextFill(Color.WHITE);
        trueButtonGoodbye.setFont(Font.font("Times new roman", FontWeight.BOLD, 25));

        Button falseButtonGoodbye = new Button("False");
        falseButtonGoodbye.setLayoutX(430.0);
        falseButtonGoodbye.setLayoutY(260.0);
        falseButtonGoodbye.setMnemonicParsing(false);
        falseButtonGoodbye.setPrefHeight(51.0);
        falseButtonGoodbye.setPrefWidth(140.0);
        falseButtonGoodbye.setStyle("-fx-background-color: #ba2222; -fx-background-radius: 20px;");
        falseButtonGoodbye.setTextAlignment(TextAlignment.CENTER);
        falseButtonGoodbye.setTextFill(Color.WHITE);
        falseButtonGoodbye.setFont(Font.font("Times new roman", FontWeight.BOLD, 25));

        Text titleText = new Text("Learn Chinese");
        titleText.setFill(Color.WHITE); // Change color to white
        titleText.setFont(Font.font("Times new roman", FontWeight.BOLD, FontPosture.ITALIC, 38)); // Change font
        titleText.setStyle("-fx-stroke: #992725;" + "-fx-stroke-width: 1;");
        titleText.setLayoutX(140);
        titleText.setLayoutY(59);
        titleText.setTextAlignment(TextAlignment.CENTER);

        Text instructionTextT = new Text("Click on the \"T\" Key if this is the correct word");
        instructionTextT.setFill(Color.web("#41774a"));
        instructionTextT.setLayoutX(200.0);
        instructionTextT.setLayoutY(350.0);
        instructionTextT.setStrokeType(StrokeType.OUTSIDE);
        instructionTextT.setFont(Font.font("Times new roman", FontWeight.BOLD, 18));

        Text instructionTextF = new Text("Click on the \"F\" Key if it is incorrect");
        instructionTextF.setFill(Color.web("#9f2424"));
        instructionTextF.setLayoutX(200.0);
        instructionTextF.setLayoutY(380.0);
        instructionTextF.setStrokeType(StrokeType.OUTSIDE);
        instructionTextF.setFont(Font.font("Times new roman", FontWeight.BOLD, 18));

        Text greetingText = new Text("Goodbye");
        greetingText.setFill(Color.WHITE);
        greetingText.setLayoutX(240.0);
        greetingText.setLayoutY(198.0);
        greetingText.setStrokeType(StrokeType.OUTSIDE);
        greetingText.setStroke(Color.web("#992725"));
        greetingText.setFont(Font.font("Times New Roman", 40.0));

        Button btHomeM1 = new Button();
        btHomeM1.setLayoutX(50.0);
        btHomeM1.setLayoutY(21.0);
        btHomeM1.setMnemonicParsing(false);
        btHomeM1.setPrefHeight(53.0);
        btHomeM1.setPrefWidth(52.0);
        btHomeM1.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView homeIcon = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        homeIcon.setFitHeight(36.0);
        homeIcon.setFitWidth(32.0);
        homeIcon.setPreserveRatio(true);
        btHomeM1.setGraphic(homeIcon);
        
        btHomeM1.setOnAction(e->{
         stage.setScene(sceneTest);
        stage.show();
         });

        Button audioButton = new Button();
        audioButton.setLayoutX(420);
        audioButton.setLayoutY(155);
        audioButton.setPrefHeight(53);
        audioButton.setPrefWidth(52);
        ImageView audioIcon = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//audio.png");
        audioIcon.setFitHeight(55);
        audioIcon.setFitWidth(50);
        audioIcon.setLayoutX(476);
        audioIcon.setLayoutY(176);
        audioButton.setGraphic(audioIcon);
        audioButton.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");

        Media byeMedia = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images/bye/bye.mp3");
        MediaPlayer byePlayer = new MediaPlayer(byeMedia);
        audioButton.setOnAction(e -> {
            byePlayer.stop(); // Stop the media if it's already playing
            byePlayer.play(); // Start playing the media
        });
        
        Pane ScoreBoxbye = new Pane();
        // Rectangle
        Rectangle rectangleByeTest = new Rectangle(173.0, 36.0);
        rectangleByeTest.setArcWidth(5.0);
        rectangleByeTest.setArcHeight(5.0);
        rectangleByeTest.setFill(Color.web("#d98471a3"));
        rectangleByeTest.setLayoutX(565.0);
        rectangleByeTest.setLayoutY(29.0);
        rectangleByeTest.setStroke(Color.WHITE);
        rectangleByeTest.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
        rectangleByeTest.setStrokeLineJoin(javafx.scene.shape.StrokeLineJoin.ROUND);
        rectangleByeTest.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        rectangleByeTest.setStrokeWidth(2.0);
        rectangleByeTest.setStyle("-fx-stroke-dash-array: 8;");

        // Label
        Label label0 = new Label(Integer.toString(score));
        label0.setLayoutX(679.0);
        label0.setLayoutY(32.0);
        label0.setTextFill(Color.web("#6d4239"));
        label0.setFont(Font.font("Imprint MT Shadow", 26.0));

        // Text
        Text textScore0 = new Text("Score:");
        textScore0.setFill(Color.web("#52352f"));
        textScore0.setFont(Font.font("Imprint MT Shadow", 26.0));
        textScore0.setLayoutX(578.0);
        textScore0.setLayoutY(56.0);

        ScoreBoxbye.getChildren().addAll(btHomeM1,rectangleByeTest, label0, textScore0);
        Button nextButtonM1 = new Button("Next");
        nextButtonM1.setLayoutX(558);
        nextButtonM1.setLayoutY(347);
        nextButtonM1.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButtonM1.setTextFill(Color.WHITE);
        nextButtonM1.setFont(Font.font(18));
        

        anchorPaneGoodbye.getChildren().addAll(backgroundImage, audioButton,nextButtonM1,
                trueButtonGoodbye, falseButtonGoodbye, titleText, instructionTextT, instructionTextF, greetingText,ScoreBoxbye);

        Scene sceneGoodbye = new Scene(anchorPaneGoodbye, 800, 400);

        nextButtonM0.setOnAction(e->{
        stage.setScene(sceneGoodbye);
        stage.show();
        });
        Media rightmp_M2 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//right.mp3");  
        MediaPlayer right_M2 = new MediaPlayer(rightmp_M2); 
   
        Media wrongmp_M2 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//wrong.mp3");  
        MediaPlayer wrong_M2 = new MediaPlayer(wrongmp_M2); 
        
         falseButtonGoodbye.setOnAction(e->{
        wrong_M2.play();
        wrong_M2.stop();
        });
      
                //-------------------Q3:Okay-----------------
                
        AnchorPane anchorPaneOkay = new AnchorPane();
        ImageView backgroundImageView = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png"));
        backgroundImageView.setFitWidth(800.0);
        backgroundImageView.setPreserveRatio(true);

        Button trueButtonOkay = new Button("True");
        trueButtonOkay.setLayoutX(200.0);
        trueButtonOkay.setLayoutY(260.0);
        trueButtonOkay.setMnemonicParsing(false);
        trueButtonOkay.setPrefHeight(51.0);
        trueButtonOkay.setPrefWidth(140.0);
        trueButtonOkay.setStyle("-fx-background-color: #41774a; -fx-background-radius: 20px;");
        trueButtonOkay.setTextAlignment(TextAlignment.CENTER);
        trueButtonOkay.setTextFill(Color.WHITE);
        trueButtonOkay.setFont(Font.font("Times new roman", FontWeight.BOLD, 25));

        Button falseButtonOkay = new Button("False");
        falseButtonOkay.setLayoutX(430.0);
        falseButtonOkay.setLayoutY(260.0);
        falseButtonOkay.setMnemonicParsing(false);
        falseButtonOkay.setPrefHeight(51.0);
        falseButtonOkay.setPrefWidth(140.0);
        falseButtonOkay.setStyle("-fx-background-color: #ba2222; -fx-background-radius: 20px;");
        falseButtonOkay.setTextAlignment(TextAlignment.CENTER);
        falseButtonOkay.setTextFill(Color.WHITE);
        falseButtonOkay.setFont(Font.font("Times new roman", FontWeight.BOLD, 25));

        Text titleTextOkay = new Text("Learn Chinese");
        titleTextOkay.setFill(Color.WHITE); // Change color to white
        titleTextOkay.setFont(Font.font("Times new roman", FontWeight.BOLD, FontPosture.ITALIC, 38)); // Change font
        titleTextOkay.setStyle("-fx-stroke: #992725;" + "-fx-stroke-width: 1;");
        titleTextOkay.setLayoutX(140);
        titleTextOkay.setLayoutY(59);
        titleTextOkay.setTextAlignment(TextAlignment.CENTER);

        Text instructionTextTOkay = new Text("Click on the \"T\" Key if this is the correct word");
        instructionTextTOkay.setFill(Color.web("#41774a"));
        instructionTextTOkay.setLayoutX(200.0);
        instructionTextTOkay.setLayoutY(350.0);
        instructionTextTOkay.setStrokeType(StrokeType.OUTSIDE);
        instructionTextTOkay.setFont(Font.font("Times new roman", FontWeight.BOLD, 18));

        Text instructionTextFOkay = new Text("Click on the \"F\" Key if it is incorrect");
        instructionTextFOkay.setFill(Color.web("#9f2424"));
        instructionTextFOkay.setLayoutX(200.0);
        instructionTextFOkay.setLayoutY(380.0);
        instructionTextFOkay.setStrokeType(StrokeType.OUTSIDE);
        instructionTextFOkay.setFont(Font.font("Times new roman", FontWeight.BOLD, 18));

        Text greetingTextOkay = new Text("Okay");
        greetingTextOkay.setFill(Color.WHITE);
        greetingTextOkay.setLayoutX(255.0);
        greetingTextOkay.setLayoutY(198.0);
        greetingTextOkay.setStrokeType(StrokeType.OUTSIDE);
        greetingTextOkay.setStroke(Color.web("#992725"));
        greetingTextOkay.setFont(Font.font("Times New Roman", 48.0));

        Button btHomeM2 = new Button();
        btHomeM2.setLayoutX(50.0);
        btHomeM2.setLayoutY(21.0);
        btHomeM2.setMnemonicParsing(false);
        btHomeM2.setPrefHeight(53.0);
        btHomeM2.setPrefWidth(52.0);
        btHomeM2.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView homeIconOkay = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        homeIconOkay.setFitHeight(36.0);
        homeIconOkay.setFitWidth(32.0);
        homeIconOkay.setPreserveRatio(true);
        btHomeM2.setGraphic(homeIconOkay);
          btHomeM2.setOnAction(e->{
         stage.setScene(sceneTest);
        stage.show();
         });

        Button audioButtonOkay = new Button();
        audioButtonOkay.setLayoutX(420);
        audioButtonOkay.setLayoutY(155);
        audioButtonOkay.setPrefHeight(53);
        audioButtonOkay.setPrefWidth(52);
        ImageView audioIconOkay = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//audio.png");
        audioIconOkay.setFitHeight(55);
        audioIconOkay.setFitWidth(50);
        audioIconOkay.setLayoutX(476);
        audioIconOkay.setLayoutY(176);
        audioButtonOkay.setGraphic(audioIconOkay);
        audioButtonOkay.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");

        Media byeMediaOkay = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images/bye/bye.mp3");
        MediaPlayer byePlayerOkay = new MediaPlayer(byeMediaOkay);
        audioButtonOkay.setOnAction(e -> {
            byePlayerOkay.stop(); // Stop the media if it's already playing
            byePlayerOkay.play(); // Start playing the media
        });
         Pane ScoreBoxok = new Pane();
        // Rectangle
        Rectangle rectangleOk = new Rectangle(173.0, 36.0);
        rectangleOk.setArcWidth(5.0);
        rectangleOk.setArcHeight(5.0);
        rectangleOk.setFill(Color.web("#d98471a3"));
        rectangleOk.setLayoutX(565.0);
        rectangleOk.setLayoutY(29.0);
        rectangleOk.setStroke(Color.WHITE);
        rectangleOk.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
        rectangleOk.setStrokeLineJoin(javafx.scene.shape.StrokeLineJoin.ROUND);
        rectangleOk.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        rectangleOk.setStrokeWidth(2.0);
        rectangleOk.setStyle("-fx-stroke-dash-array: 8;");

        // Label
        Label label1 = new Label(Integer.toString(score));
        label1.setLayoutX(679.0);
        label1.setLayoutY(32.0);
        label1.setTextFill(Color.web("#6d4239"));
        label1.setFont(Font.font("Imprint MT Shadow", 26.0));

        // Text
        Text textScore1 = new Text("Score:");
        textScore1.setFill(Color.web("#52352f"));
        textScore1.setFont(Font.font("Imprint MT Shadow", 26.0));
        textScore1.setLayoutX(578.0);
        textScore1.setLayoutY(56.0);

        ScoreBoxok.getChildren().addAll(btHomeM2,rectangleOk, label1, textScore1);
        
        Button nextButtonM3 = new Button("Next");
        nextButtonM3.setLayoutX(558);
        nextButtonM3.setLayoutY(347);
        nextButtonM3.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButtonM3.setTextFill(Color.WHITE);
        nextButtonM3.setFont(Font.font(18));
        nextButtonM3.setOnAction(e->{
            stage.setScene(sceneTest);
            stage.show();
        });
        anchorPaneOkay.getChildren().addAll(backgroundImageView, audioButtonOkay,ScoreBoxok,nextButtonM3,
                trueButtonOkay, falseButtonOkay, titleTextOkay, instructionTextTOkay, instructionTextFOkay, greetingTextOkay);

        Scene sceneOkay = new Scene(anchorPaneOkay, 800, 400);
        nextButtonM1.setOnAction(e->{
         stage.setScene(sceneOkay);
        stage.show();
        });
        
        Media rightmp_M3 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//right.mp3");  
        MediaPlayer right_M3 = new MediaPlayer(rightmp_M3); 
   
        Media wrongmp_M3 = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//wrong.mp3");  
        MediaPlayer wrong_M3 = new MediaPlayer(wrongmp_M3); 
        
        falseButtonOkay.setOnAction(e->{
        right_M3.play();
        right_M3.stop();
        });

    //------------test level Hard -------------------------------
        ImageView backgroundImageHard1 = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png"));
        backgroundImageHard1.setFitWidth(800.0);
        backgroundImageHard1.setPreserveRatio(true);
        
        Button btHomeHard0 = new Button();
        btHomeHard0.setLayoutX(50.0);
        btHomeHard0.setLayoutY(21.0);
        btHomeHard0.setMnemonicParsing(false);
        btHomeHard0.setPrefHeight(53.0);
        btHomeHard0.setPrefWidth(52.0);
        btHomeHard0.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView HomeiconHard0 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        HomeiconHard0.setFitHeight(36.0);
        HomeiconHard0.setFitWidth(32.0);
        HomeiconHard0.setPreserveRatio(true);
        btHomeHard0.setGraphic(HomeiconHard0);
        btHomeHard0.setOnAction(e->{
            stage.setScene(sceneTest);
           stage.show();
            });

        Button nextButtonOkay0 = new Button("Next");
        nextButtonOkay0.setLayoutX(558);
        nextButtonOkay0.setLayoutY(347);
        nextButtonOkay0.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButtonOkay0.setTextFill(Color.WHITE);
        nextButtonOkay0.setFont(Font.font(18));

        // Rectangle
        Rectangle rectangleHard1 = new Rectangle(173.0, 36.0);
        rectangleHard1.setArcWidth(5.0);
        rectangleHard1.setArcHeight(5.0);
        rectangleHard1.setFill(Color.web("#d98471a3"));
        rectangleHard1.setLayoutX(565.0);
        rectangleHard1.setLayoutY(29.0);
        rectangleHard1.setStroke(Color.WHITE);
        rectangleHard1.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
        rectangleHard1.setStrokeLineJoin(javafx.scene.shape.StrokeLineJoin.ROUND);
        rectangleHard1.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        rectangleHard1.setStrokeWidth(2.0);
        rectangleHard1.setStyle("-fx-stroke-dash-array: 8;");

        // Label
        Label labelHard1 = new Label(Integer.toString(score));
        labelHard1.setLayoutX(679.0);
        labelHard1.setLayoutY(32.0);
        labelHard1.setTextFill(Color.web("#6d4239"));
        labelHard1.setFont(Font.font("Imprint MT Shadow", 26.0));

        // Text
        Text text0 = new Text("Score:");
        text0.setFill(Color.web("#52352f"));
        text0.setFont(Font.font("Imprint MT Shadow", 26.0));
        text0.setLayoutX(578.0);
        text0.setLayoutY(56.0);

        Text text1 = new Text("你好");//the word is hi
        text1.setX(290);
        text1.setY(220);
        text1.setFont(Font.font(100));
        
        TextField textField0 = new TextField();
        textField0.setLayoutX(320);
        textField0.setLayoutY(250);
        textField0.setStyle("-fx-background-color: #d98471a3; -fx-background-radius: 5px;-fx-prompt-text-fill: WHITE;");
        textField0.setPromptText("enter the right answer");

        //submit buuton
        Button submitButton0 = new Button("submit");
        submitButton0.setLayoutX(360);
        submitButton0.setLayoutY(285);
        submitButton0.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        submitButton0.setTextFill(Color.WHITE);
        submitButton0.setFont(Font.font(16));

        ///////////////////////////////////////////////////////
        Pane p = new Pane();
        Pane p2 = new Pane();
        Pane p3 = new Pane();

        Scene sceneHard2 = new Scene(p2,800,400);
        Scene sceneHard1 = new Scene(p, 800,400);
        Scene sceneHard3 =new Scene(p3,800,400);

        nextButtonOkay0.setOnAction(actionEvent ->{stage.setScene(sceneHard2);} );

        ImageView imageView2 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
        imageView2.setFitWidth(800);
        imageView2.setPreserveRatio(true);

        Button btHomebye2 = new Button();
        btHomebye2.setLayoutX(50.0);
        btHomebye2.setLayoutY(21.0);
        btHomebye2.setMnemonicParsing(false);
        btHomebye2.setPrefHeight(53.0);
        btHomebye2.setPrefWidth(52.0);
        btHomebye2.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView Homeiconbye2 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        Homeiconbye2.setFitHeight(36.0);
        Homeiconbye2.setFitWidth(32.0);
        Homeiconbye2.setPreserveRatio(true);
        btHomebye2.setGraphic(Homeiconbye2);
        btHomebye2.setOnAction(e->{
         stage.setScene(sceneTest);
        stage.show();
         });

        Button nextButtonHard2 = new Button("Next");
        nextButtonHard2.setLayoutX(558);
        nextButtonHard2.setLayoutY(347);
        nextButtonHard2.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButtonHard2.setTextFill(Color.WHITE);
        nextButtonHard2.setFont(Font.font(18));

        Rectangle rectangleHard3 = new Rectangle(173.0, 36.0);
        rectangleHard3.setArcWidth(5.0);
        rectangleHard3.setArcHeight(5.0);
        rectangleHard3.setFill(Color.web("#d98471a3"));
        rectangleHard3.setLayoutX(565.0);
        rectangleHard3.setLayoutY(29.0);
        rectangleHard3.setStroke(Color.WHITE);
        rectangleHard3.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
        rectangleHard3.setStrokeLineJoin(javafx.scene.shape.StrokeLineJoin.ROUND);
        rectangleHard3.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        rectangleHard3.setStrokeWidth(2.0);
        rectangleHard3.setStyle("-fx-stroke-dash-array: 8;");

        Label label2 = new Label(Integer.toString(score));
        label2.setLayoutX(679.0);
        label2.setLayoutY(32.0);
        label2.setTextFill(Color.web("#6d4239"));
        label2.setFont(Font.font("Imprint MT Shadow", 26.0));

        // Text
        Text textHard = new Text("Score:");
        textHard.setFill(Color.web("#52352f"));
        textHard.setFont(Font.font("Imprint MT Shadow", 26.0));
        textHard.setLayoutX(578.0);
        textHard.setLayoutY(56.0);

        TextField textField2 = new TextField();
        textField2.setLayoutX(320);
        textField2.setLayoutY(250);
        textField2.setStyle("-fx-background-color: #d98471a3; -fx-background-radius: 5px;-fx-prompt-text-fill: WHITE;");
        textField2.setPromptText("enter the right answer");

        //submit buuton
        Button submitButton2 = new Button("submit");
        submitButton2.setLayoutX(360);
        submitButton2.setLayoutY(285);
        submitButton2.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        submitButton2.setTextFill(Color.WHITE);
        submitButton2.setFont(Font.font(16));

        Button backButtonHard0 = new Button("Back");
        backButtonHard0.setLayoutX(178);
        backButtonHard0.setLayoutY(347);
        backButtonHard0.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        backButtonHard0.setTextFill(Color.WHITE);
        backButtonHard0.setFont(Font.font(18));
        backButtonHard0.setOnAction(actionEvent -> {stage.setScene(sceneHard1);}   );

        Text textHard2 = new Text("谢谢");//the word is thanks
        textHard2.setX(290);
        textHard2.setY(220);
        textHard2.setFont(Font.font(100));

        //// scene3
        nextButtonHard2.setOnAction(actionEvent ->{stage.setScene(sceneHard3);} );

        ImageView imageView3 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
        imageView3.setFitWidth(800);
        imageView3.setPreserveRatio(true);

        Button btHomebye3 = new Button();
        btHomebye3.setLayoutX(50.0);
        btHomebye3.setLayoutY(21.0);
        btHomebye3.setMnemonicParsing(false);
        btHomebye3.setPrefHeight(53.0);
        btHomebye3.setPrefWidth(52.0);
        btHomebye3.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        ImageView Homeiconbye3 = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
        Homeiconbye3.setFitHeight(36.0);
        Homeiconbye3.setFitWidth(32.0);
        Homeiconbye3.setPreserveRatio(true);
        btHomebye3.setGraphic(Homeiconbye3);
        btHomebye3.setOnAction(e->{
         stage.setScene(sceneTest);
        stage.show();
         });

        Rectangle rectangleHard = new Rectangle(173.0, 36.0);
        rectangleHard.setArcWidth(5.0);
        rectangleHard.setArcHeight(5.0);
        rectangleHard.setFill(Color.web("#d98471a3"));
        rectangleHard.setLayoutX(565.0);
        rectangleHard.setLayoutY(29.0);
        rectangleHard.setStroke(Color.WHITE);
        rectangleHard.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
        rectangleHard.setStrokeLineJoin(javafx.scene.shape.StrokeLineJoin.ROUND);
        rectangleHard.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
        rectangleHard.setStrokeWidth(2.0);
        rectangleHard.setStyle("-fx-stroke-dash-array: 8;");

        Label label3 = new Label(Integer.toString(score));
        label3.setLayoutX(679.0);
        label3.setLayoutY(32.0);
        label3.setTextFill(Color.web("#6d4239"));
        label3.setFont(Font.font("Imprint MT Shadow", 26.0));

        // Text
        Text text3 = new Text("Score:");
        //text3.setFill(Color.web("#52352f"));
        text3.setFont(Font.font("Imprint MT Shadow", 26.0));
        text3.setLayoutX(578.0);
        text3.setLayoutY(56.0);

        TextField textField3 = new TextField();
        textField3.setLayoutX(320);
        textField3.setLayoutY(250);
        textField3.setStyle("-fx-background-color: #d98471a3; -fx-background-radius: 5px;-fx-prompt-text-fill: WHITE;");
        textField3.setPromptText("enter the right answer");

        //submit buuton
        Button submitButton3 = new Button("submit");
        submitButton3.setLayoutX(360);
        submitButton3.setLayoutY(285);
        submitButton3.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        submitButton3.setTextFill(Color.WHITE);
        submitButton3.setFont(Font.font(16));

        Button backButtonHard2 = new Button("Back");
        backButtonHard2.setLayoutX(178);
        backButtonHard2.setLayoutY(347);
        backButtonHard2.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        backButtonHard2.setTextFill(Color.WHITE);
        backButtonHard2.setFont(Font.font(18));
        backButtonHard2.setOnAction(actionEvent -> {stage.setScene(sceneHard2);}   );

         Button nextButtonHard3 = new Button("Next");
        nextButtonHard3.setLayoutX(558);
        nextButtonHard3.setLayoutY(347);
        nextButtonHard3.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        nextButtonHard3.setTextFill(Color.WHITE);
        nextButtonHard3.setFont(Font.font(18));

        Text text33 = new Text("是的");//the word is yes
        text33.setX(290);
        text33.setY(220);
        text33.setFont(Font.font(100));


        p.getChildren().addAll(backgroundImageHard1,btHomeHard0,rectangleHard1,nextButtonOkay0,text0,labelHard1,textField0,submitButton0,text1);
        p2.getChildren().addAll(imageView2,btHomebye2,rectangleHard3,nextButtonHard2,textHard2,label2,textField2,submitButton2,backButtonHard0,textHard);
        p3.getChildren().addAll(imageView3,btHomebye3,rectangleHard,nextButtonHard3,text3,label3,textField3,submitButton3,backButtonHard2,text33);
        
        button3.setOnAction(e->{
            if(score>=40){
         stage.setScene(sceneHard1);
        stage.setTitle("Test Level Middle");
        stage.show(); }
            else{
       BorderPane successBorderPane= new BorderPane();
       Rectangle successRect = new Rectangle(400, 50); // Adjust the dimensions as needed
    successRect.setFill(Color.rgb(220, 131, 111, 0.57));
    successRect.setLayoutX(200);
    successRect.setLayoutY(200);
    successRect.setStroke(Color.WHITE);
            successRect.setStrokeLineCap(javafx.scene.shape.StrokeLineCap.ROUND);
            successRect.setStrokeLineJoin(javafx.scene.shape.StrokeLineJoin.ROUND);
            successRect.setStrokeType(javafx.scene.shape.StrokeType.OUTSIDE);
            successRect.setStrokeWidth(2.0);
            successRect.setStyle("-fx-stroke-dash-array: 8;");

    Text successText = new Text("You have to get 40 score");
    successText.setFill(Color.WHITE);
    successText.setFont(Font.font("Helvetica", FontWeight.BOLD, 20));
    successText.setLayoutX(295);
    successText.setLayoutY(230);

    Image backgroundImage3 = new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
    ImageView imageView = new ImageView(backgroundImage3);
    imageView.setFitWidth(800); // Set the width of the image view
    imageView.setFitHeight(400); // Set the height of the image view

    Pane combinedPane = new Pane();
    combinedPane.getChildren().addAll(imageView, successRect, successText);
    successBorderPane.getChildren().add(combinedPane);

    Scene successScene = new Scene(successBorderPane, 800, 400);
    stage.setScene(successScene);
    stage.show();

            // Set up a timeline to remove the success message after a certain duration
            Duration displayDuration = Duration.seconds(1); // Adjust the duration as needed
            Timeline timeline = new Timeline(new KeyFrame(displayDuration, event -> {
                // Remove the success message
                stage.setScene(sceneTest); // Set the scene back to the login scene
                stage.show();
            }));
            timeline.play();
        }
    });
        
                //-----------***********Score Lables********-----------
          //-------------easy--------------      
        helloButton_T1.setOnAction(e ->{  
        right_Q1.stop(); // Stop the media if it's already playing
        right_Q1.play(); // Start playing the media
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        Transaction tx = session.beginTransaction();
        increaseScore2();
        scoreLabel.setText(Integer.toString(score));
        
        scoreLabel_T1.setText(Integer.toString(score));
        scoreLabel_T2.setText(Integer.toString(score));
        scoreLabel_T3.setText(Integer.toString(score));
        scoreLabel_T4.setText(Integer.toString(score));
        scoreLabel_T5.setText(Integer.toString(score));
        
        label.setText(Integer.toString(score));
        label0.setText(Integer.toString(score));
        label1.setText(Integer.toString(score));
        
        labelHard1.setText(Integer.toString(score));
        label2.setText(Integer.toString(score));
        label3.setText(Integer.toString(score));

        // Create a new Test
        Test newTest = new Test();
        newTest.setScore(score); // Set the score based on the label value
        newTest.setgameLevel("Easy");
        newTest.setId(1);
        newTest.setUserid(newUser);
        // Save the test to the database
        session.save(newTest);
        tx.commit();

    } catch (Exception ex) {
        ex.printStackTrace();
        // Handle other exceptions
    }    
         }) ;
        
        ThirdButton_T2.setOnAction(e ->{  
        right_Q2.stop(); // Stop the media if it's already playing
        right_Q2.play(); // Start playing the media
        
         try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        Transaction tx = session.beginTransaction();
        increaseScore2();
        scoreLabel.setText(Integer.toString(score));
        
        scoreLabel_T1.setText(Integer.toString(score));
        scoreLabel_T2.setText(Integer.toString(score));
        scoreLabel_T3.setText(Integer.toString(score));
        scoreLabel_T4.setText(Integer.toString(score));
        scoreLabel_T5.setText(Integer.toString(score));
        
        label.setText(Integer.toString(score));
        label0.setText(Integer.toString(score));
        label1.setText(Integer.toString(score));
        
        labelHard1.setText(Integer.toString(score));
        label2.setText(Integer.toString(score));
        label3.setText(Integer.toString(score));

        // Create a new Test
        Test newTest = new Test();
        newTest.setScore(score); // Set the score based on the label value
        newTest.setgameLevel("Easy");
        newTest.setId(1);
      //  newTest.setUserid(newUser);
        // Save the test to the database
        session.save(newTest);
        tx.commit();

    } catch (Exception ex) {
        ex.printStackTrace();
        // Handle other exceptions
    }    
        
         }) ;
        
        FirstButton_T3.setOnAction(e ->{  
        right_Q3.stop(); // Stop the media if it's already playing
        right_Q3.play(); // Start playing the media
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        Transaction tx = session.beginTransaction();
        increaseScore2();
        scoreLabel.setText(Integer.toString(score));
        
        scoreLabel_T1.setText(Integer.toString(score));
        scoreLabel_T2.setText(Integer.toString(score));
        scoreLabel_T3.setText(Integer.toString(score));
        scoreLabel_T4.setText(Integer.toString(score));
        scoreLabel_T5.setText(Integer.toString(score));
        
        label.setText(Integer.toString(score));
        label0.setText(Integer.toString(score));
        label1.setText(Integer.toString(score));
        
        labelHard1.setText(Integer.toString(score));
        label2.setText(Integer.toString(score));
        label3.setText(Integer.toString(score));

        // Create a new Test
        Test newTest = new Test();
        newTest.setScore(score); // Set the score based on the label value
        newTest.setgameLevel("Easy");
        newTest.setId(1);
      //  newTest.setUserid(newUser);
        // Save the test to the database
        session.save(newTest);
        tx.commit();

    } catch (Exception ex) {
        ex.printStackTrace();
        // Handle other exceptions
    }    
         }) ;
        
        SecoundButton_T4.setOnAction(e ->{  
        right_Q4.stop(); // Stop the media if it's already playing
        right_Q4.play(); // Start playing the media
        
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        Transaction tx = session.beginTransaction();
        increaseScore2();
        scoreLabel.setText(Integer.toString(score));
        
        scoreLabel_T1.setText(Integer.toString(score));
        scoreLabel_T2.setText(Integer.toString(score));
        scoreLabel_T3.setText(Integer.toString(score));
        scoreLabel_T4.setText(Integer.toString(score));
        scoreLabel_T5.setText(Integer.toString(score));
        
        label.setText(Integer.toString(score));
        label0.setText(Integer.toString(score));
        label1.setText(Integer.toString(score));
        
        labelHard1.setText(Integer.toString(score));
        label2.setText(Integer.toString(score));
        label3.setText(Integer.toString(score));

        // Create a new Test
        Test newTest = new Test();
        newTest.setScore(score); // Set the score based on the label value
        newTest.setgameLevel("Easy");
        newTest.setId(1);
      //  newTest.setUserid(newUser);
        // Save the test to the database
        session.save(newTest);
        tx.commit();

    } catch (Exception ex) {
        ex.printStackTrace();
        // Handle other exceptions
    }  
         }) ;
        
        ThirdButton_T5.setOnAction(e ->{  
        right_Q5.stop(); // Stop the media if it's already playing
        right_Q5.play(); // Start playing the media
        
       try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        Transaction tx = session.beginTransaction();
        increaseScore2();
        scoreLabel.setText(Integer.toString(score));
        
        scoreLabel_T1.setText(Integer.toString(score));
        scoreLabel_T2.setText(Integer.toString(score));
        scoreLabel_T3.setText(Integer.toString(score));
        scoreLabel_T4.setText(Integer.toString(score));
        scoreLabel_T5.setText(Integer.toString(score));
        
        label.setText(Integer.toString(score));
        label0.setText(Integer.toString(score));
        label1.setText(Integer.toString(score));
        
        labelHard1.setText(Integer.toString(score));
        label2.setText(Integer.toString(score));
        label3.setText(Integer.toString(score));

        // Create a new Test
        Test newTest = new Test();
        newTest.setScore(score); // Set the score based on the label value
        newTest.setgameLevel("Easy");
        newTest.setId(1);
      //  newTest.setUserid(newUser);
        // Save the test to the database
        session.save(newTest);
        tx.commit();

    } catch (Exception ex) {
        ex.printStackTrace();
        // Handle other exceptions
    }  
         }) ;
                
                //-----middle score------------
    sceneTestHello.setOnKeyPressed(event -> {
    if (event.getCode() == KeyCode.T) {
        right_M1.play();
        right_M1.stop();
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        Transaction tx = session.beginTransaction();
        increaseScore10();
        scoreLabel.setText(Integer.toString(score));
        
        scoreLabel_T1.setText(Integer.toString(score));
        scoreLabel_T2.setText(Integer.toString(score));
        scoreLabel_T3.setText(Integer.toString(score));
        scoreLabel_T4.setText(Integer.toString(score));
        scoreLabel_T5.setText(Integer.toString(score));
        
        label.setText(Integer.toString(score));
        label0.setText(Integer.toString(score));
        label1.setText(Integer.toString(score));
        
        labelHard1.setText(Integer.toString(score));
        label2.setText(Integer.toString(score));
        label3.setText(Integer.toString(score));

        // Create a new Test
        Test newTest = new Test();
        newTest.setScore(score); // Set the score based on the label value
        newTest.setgameLevel("Middle");
        newTest.setId(2);
      //  newTest.setUserid(newUser);
        // Save the test to the database
        session.save(newTest);
        tx.commit();

    } catch (Exception ex) {
        ex.printStackTrace();
        // Handle other exceptions
    }
    }else{
        wrong_M1.play();
        wrong_M1.stop();
    }
});
    sceneGoodbye.setOnKeyPressed(event -> {
    if (event.getCode() == KeyCode.T) {
        right_M2.play();
        right_M2.stop();
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        Transaction tx = session.beginTransaction();
        increaseScore10();
        scoreLabel.setText(Integer.toString(score));
        
        scoreLabel_T1.setText(Integer.toString(score));
        scoreLabel_T2.setText(Integer.toString(score));
        scoreLabel_T3.setText(Integer.toString(score));
        scoreLabel_T4.setText(Integer.toString(score));
        scoreLabel_T5.setText(Integer.toString(score));
        
        label.setText(Integer.toString(score));
        label0.setText(Integer.toString(score));
        label1.setText(Integer.toString(score));
        
        labelHard1.setText(Integer.toString(score));
        label2.setText(Integer.toString(score));
        label3.setText(Integer.toString(score));

        // Create a new Test
        Test newTest = new Test();
        newTest.setScore(score); // Set the score based on the label value
        newTest.setgameLevel("Middle");
        newTest.setId(2);
      //  newTest.setUserid(newUser);
        // Save the test to the database
        session.save(newTest);
        tx.commit();

    } catch (Exception ex) {
        ex.printStackTrace();
        // Handle other exceptions
    }
    }else{
        wrong_M2.play();
        wrong_M2.stop();
    }
});
        
    sceneOkay.setOnKeyPressed(event -> {
    if (event.getCode() == KeyCode.F ) {
        right_M3.play();
       // right_M3.stop();
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        Transaction tx = session.beginTransaction();
        increaseScore10();
        scoreLabel.setText(Integer.toString(score));
        
        scoreLabel_T1.setText(Integer.toString(score));
        scoreLabel_T2.setText(Integer.toString(score));
        scoreLabel_T3.setText(Integer.toString(score));
        scoreLabel_T4.setText(Integer.toString(score));
        scoreLabel_T5.setText(Integer.toString(score));
        
        label.setText(Integer.toString(score));
        label0.setText(Integer.toString(score));
        label1.setText(Integer.toString(score));
        
        labelHard1.setText(Integer.toString(score));
        label2.setText(Integer.toString(score));
        label3.setText(Integer.toString(score));

        // Create a new Test
        Test newTest = new Test();
        newTest.setScore(score); // Set the score based on the label value
        newTest.setgameLevel("Middle");
        newTest.setId(2);
      //  newTest.setUserid(newUser);
        // Save the test to the database
        session.save(newTest);
        tx.commit();

    } catch (Exception ex) {
        ex.printStackTrace();
        // Handle other exceptions
    }
    }else{
        wrong_M3.play();
        wrong_M3.stop();
    }
});
  
        trueButton.setOnAction(e -> {
        right_M1.play();
        right_M1.stop();
    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        Transaction tx = session.beginTransaction();
        increaseScore10();
        scoreLabel.setText(Integer.toString(score));
        
        scoreLabel_T1.setText(Integer.toString(score));
        scoreLabel_T2.setText(Integer.toString(score));
        scoreLabel_T3.setText(Integer.toString(score));
        scoreLabel_T4.setText(Integer.toString(score));
        scoreLabel_T5.setText(Integer.toString(score));
        
        label.setText(Integer.toString(score));
        label0.setText(Integer.toString(score));
        label1.setText(Integer.toString(score));
        
        labelHard1.setText(Integer.toString(score));
        label2.setText(Integer.toString(score));
        label3.setText(Integer.toString(score));

        // Create a new Test
        Test newTest = new Test();
        newTest.setScore(score); // Set the score based on the label value
        newTest.setgameLevel("Middle");
        newTest.setId(2);
      //  newTest.setUserid(newUser);
        // Save the test to the database
        session.save(newTest);
        tx.commit();

    } catch (Exception ex) {
        ex.printStackTrace();
        // Handle other exceptions
    }
});
        trueButtonGoodbye.setOnAction(e -> {
        right_M2.play();
        right_M2.stop();
    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        Transaction tx = session.beginTransaction();
        increaseScore10();
        scoreLabel.setText(Integer.toString(score));
        
        scoreLabel_T1.setText(Integer.toString(score));
        scoreLabel_T2.setText(Integer.toString(score));
        scoreLabel_T3.setText(Integer.toString(score));
        scoreLabel_T4.setText(Integer.toString(score));
        scoreLabel_T5.setText(Integer.toString(score));
        
        label.setText(Integer.toString(score));
        label0.setText(Integer.toString(score));
        label1.setText(Integer.toString(score));
        
        labelHard1.setText(Integer.toString(score));
        label2.setText(Integer.toString(score));
        label3.setText(Integer.toString(score));

        // Create a new Test
        Test newTest = new Test();
        newTest.setScore(score); // Set the score based on the label value
        newTest.setgameLevel("Middle");
        newTest.setId(2);
      //  newTest.setUserid(newUser);
        // Save the test to the database
        session.save(newTest);
        tx.commit();

    } catch (Exception ex) {
        ex.printStackTrace();
        // Handle other exceptions
    }
});
        
 falseButtonOkay.setOnAction(e -> {
        right_M3.play();
        right_M3.stop();
    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        Transaction tx = session.beginTransaction();
        increaseScore10();
        scoreLabel.setText(Integer.toString(score));
        
        scoreLabel_T1.setText(Integer.toString(score));
        scoreLabel_T2.setText(Integer.toString(score));
        scoreLabel_T3.setText(Integer.toString(score));
        scoreLabel_T4.setText(Integer.toString(score));
        scoreLabel_T5.setText(Integer.toString(score));
        
        label.setText(Integer.toString(score));
        label0.setText(Integer.toString(score));
        label1.setText(Integer.toString(score));
        
        labelHard1.setText(Integer.toString(score));
        label2.setText(Integer.toString(score));
        label3.setText(Integer.toString(score));

        // Create a new Test
        Test newTest = new Test();
        newTest.setScore(score); // Set the score based on the label value
        newTest.setgameLevel("Middle");
        newTest.setId(2);
      //  newTest.setUserid(newUser);
        // Save the test to the database
        session.save(newTest);
        tx.commit();
    } catch (Exception ex) {
        ex.printStackTrace();
        // Handle other exceptions
    }
});
 
 //-----------level hard--------------------------------------
        submitButton0.setOnAction(e->{
             String answer = textField0.getText();
            if (answer.equalsIgnoreCase("hello")) {
            try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        Transaction tx = session.beginTransaction();
        increaseScore20();
        scoreLabel.setText(Integer.toString(score));
        
        scoreLabel_T1.setText(Integer.toString(score));
        scoreLabel_T2.setText(Integer.toString(score));
        scoreLabel_T3.setText(Integer.toString(score));
        scoreLabel_T4.setText(Integer.toString(score));
        scoreLabel_T5.setText(Integer.toString(score));
        
        label.setText(Integer.toString(score));
        label0.setText(Integer.toString(score));
        label1.setText(Integer.toString(score));
        
        labelHard1.setText(Integer.toString(score));
        label2.setText(Integer.toString(score));
        label3.setText(Integer.toString(score));
        
        // Create a new Test
        Test newTest = new Test();
        newTest.setScore(score); // Set the score based on the label value
        newTest.setgameLevel("Hard");
        newTest.setId(3);
      //  newTest.setUserid(newUser);
        // Save the test to the database
        session.save(newTest);
        tx.commit();

    } catch (Exception ex) {
        ex.printStackTrace();
        // Handle other exceptions
    }  
            }    
        });
        
submitButton2.setOnAction(e->{
             String answer = textField2.getText();
            if (answer.equalsIgnoreCase("thank you")) {
            try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        Transaction tx = session.beginTransaction();
        increaseScore20();
        scoreLabel.setText(Integer.toString(score));
        
        scoreLabel_T1.setText(Integer.toString(score));
        scoreLabel_T2.setText(Integer.toString(score));
        scoreLabel_T3.setText(Integer.toString(score));
        scoreLabel_T4.setText(Integer.toString(score));
        scoreLabel_T5.setText(Integer.toString(score));
        
        label.setText(Integer.toString(score));
        label0.setText(Integer.toString(score));
        label1.setText(Integer.toString(score));
        
        labelHard1.setText(Integer.toString(score));
        label2.setText(Integer.toString(score));
        label3.setText(Integer.toString(score));

      
        
        // Create a new Test
        Test newTest = new Test();
        newTest.setScore(score); // Set the score based on the label value
        newTest.setgameLevel("Hard");
        newTest.setId(3);
      //  newTest.setUserid(newUser);
        // Save the test to the database
        session.save(newTest);
        tx.commit();

    } catch (Exception ex) {
        ex.printStackTrace();
        // Handle other exceptions
    }  
            }    
        });
        
        submitButton3.setOnAction(e->{
             String answer = textField3.getText();
            if (answer.equalsIgnoreCase("yes")) {
            try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        Transaction tx = session.beginTransaction();
        increaseScore20();
        scoreLabel.setText(Integer.toString(score));
        
        scoreLabel_T1.setText(Integer.toString(score));
        scoreLabel_T2.setText(Integer.toString(score));
        scoreLabel_T3.setText(Integer.toString(score));
        scoreLabel_T4.setText(Integer.toString(score));
        scoreLabel_T5.setText(Integer.toString(score));
        
        label.setText(Integer.toString(score));
        label0.setText(Integer.toString(score));
        label1.setText(Integer.toString(score));
        
        labelHard1.setText(Integer.toString(score));
        label2.setText(Integer.toString(score));
        label3.setText(Integer.toString(score));
        
        // Create a new Test
        Test newTest = new Test();
        newTest.setScore(score); // Set the score based on the label value
        newTest.setgameLevel("Hard");
        newTest.setId(3);
      //  newTest.setUserid(newUser);
        // Save the test to the database
        session.save(newTest);
        tx.commit();

    } catch (Exception ex) {
        ex.printStackTrace();
        // Handle other exceptions
    }  
            }    
        });
 
   //----------------------congratulations scene------------------
        AnchorPane anchorPane_conMsg = new AnchorPane();

        ImageView background_con = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png"));
        background_con.setFitWidth(800.0);
        background_con.setPreserveRatio(true);
        
        anchorPane_conMsg.getChildren().add(background_con);

        Text text_con = new Text("LearnChinese");
        text_con.setFill(Color.WHITE);
        text_con.setFont(Font.font("Imprint MT Shadow", 38.0));
        text_con.setLayoutX(140.0);
        text_con.setLayoutY(59.0);
        anchorPane_conMsg.getChildren().add(text_con);

        Rectangle rectangle_con = new Rectangle(436.0, 236.0);
        rectangle_con.setArcHeight(5.0);
        rectangle_con.setArcWidth(5.0);
        rectangle_con.setFill(Color.rgb(220, 131, 111, 0.57));
        rectangle_con.setLayoutX(191.0);
        rectangle_con.setLayoutY(74.0);
        rectangle_con.setStroke(Color.WHITE);
        rectangle_con.setStrokeWidth(2.0);
        rectangle_con.setStyle("-fx-stroke-dash-array: 10;");
        anchorPane_conMsg.getChildren().add(rectangle_con);

        Button btHome_con = new Button();
        btHome_con.setLayoutX(86.0);
        btHome_con.setLayoutY(21.0);
        btHome_con.setPrefHeight(53.0);
        btHome_con.setPrefWidth(52.0);
        btHome_con.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
        anchorPane_conMsg.getChildren().add(btHome_con);
        
        btHome_con.setOnAction(e->{
            stage.setScene(sceneTest);
            stage.show();
        });

        ImageView homeIcon_con = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png"));
        homeIcon_con.setFitHeight(36.0);
        homeIcon_con.setFitWidth(32.0);
        homeIcon_con.setLayoutX(96.0);
        homeIcon_con.setLayoutY(31.0);
        homeIcon_con.setPreserveRatio(true);
        anchorPane_conMsg.getChildren().add(homeIcon_con);

        Text congratulationText = new Text("祝贺");
        congratulationText.setFill(Color.rgb(253, 247, 246));
        congratulationText.setFont(Font.font("Arial", 47.0));
        congratulationText.setLayoutX(362.0);
        congratulationText.setLayoutY(117.0);
        anchorPane_conMsg.getChildren().add(congratulationText);

        Text conMessageText = new Text("Congratulations on your success! Your dedication and effort have truly paid off. Keep up the great work!");
        conMessageText.setFill(Color.rgb(253, 247, 246));
        conMessageText.setFont(Font.font("Baskerville Old Face", 28.0));
        conMessageText.setLayoutX(207.0);
        conMessageText.setLayoutY(155.0);
        conMessageText.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        conMessageText.setWrappingWidth(404.388671875);
        anchorPane_conMsg.getChildren().add(conMessageText);

        Label name_con = new Label();
        Color nameCCon = Color.rgb(253, 247, 246);
        name_con.setTextFill(nameCCon);
        name_con.setFont(Font.font("Baskerville Old Face", 20.0));
        name_con.setLayoutX(530.0);
        name_con.setLayoutY(280.0);
        
        name_con.textProperty().bind(usertf1.textProperty());
        anchorPane_conMsg.getChildren().add(name_con);

        ImageView fireworkIcon = new ImageView(new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//firework.png"));
        fireworkIcon.setFitHeight(79.0);
        fireworkIcon.setFitWidth(84.0);
        fireworkIcon.setLayoutX(197.0);
        fireworkIcon.setLayoutY(231.0);
        fireworkIcon.setPreserveRatio(true);
        anchorPane_conMsg.getChildren().add(fireworkIcon);

        anchorPane_conMsg.setStyle("-fx-background-color: radial-gradient(radius 50%, transparent, white);");
        
        Media clappingM = new Media("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//clapping.mp3");
        MediaPlayer clappingP = new MediaPlayer(clappingM);
        Scene conMsgScene = new Scene(anchorPane_conMsg, 800, 400);
        conMsgScene.setOnMousePressed(e->{
            clappingP.stop();
            clappingP.play();
        });
        nextButtonHard3.setOnAction(e->{
        stage.setScene(conMsgScene);
        stage.show();
        });
               
    //--------------********Scene Rating******************--------------------
         //Create Stage
    stage.setTitle("LearnChinese");

    //Create root pane
    BorderPane root = new BorderPane();

    //Set background image
    Image bgImage = new Image("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//chbackground.png");
    BackgroundImage bg = new BackgroundImage(bgImage, BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, 
            BackgroundPosition.CENTER, new BackgroundSize(800, 400, false, false, false, false));

    //Create title label
    Label title = new Label("LearnChinese");
    title.setFont(Font.font("Times new roman", FontWeight.BOLD,FontPosture.ITALIC, 38)); // Change font
    title.setTextFill(Color.WHITE);
    title.setStyle("-fx-stroke: #992725;-fx-stroke-width: 1;");
    title.setAlignment(Pos.BOTTOM_CENTER);

    //Create home icon
    Button btHomeRating = new Button();
    btHomeRating.setLayoutX(50.0);
    btHomeRating.setLayoutY(21.0);
    btHomeRating.setMnemonicParsing(false);
    btHomeRating.setPrefHeight(53.0);
    btHomeRating.setPrefWidth(52.0);
    btHomeRating.setStyle("-fx-background-radius: 100px; -fx-background-color: #dc836f; -fx-border-color: white; -fx-border-radius: 100px;");
    ImageView HomeiconRating = new ImageView("file:///C://Users//vip//OneDrive//سطح%20المكتب//Ap_Project//images//home.png");
    HomeiconRating.setFitHeight(36.0);
    HomeiconRating.setFitWidth(32.0);
    HomeiconRating.setPreserveRatio(true);
    btHomeRating.setGraphic(HomeiconRating);
    btHomeRating.setOnAction(e->{
        stage.setScene(sceneMany);
       stage.show();
        });

    //Create header
    HBox header = new HBox();
    header.getChildren().addAll(btHomeRating,title);
    header.setPadding(new Insets(50));
    header.setSpacing(10);

    //Create rating label
    Label ratingLabel = new Label("Rating Section");
    ratingLabel.setFont(Font.font("Times new roman", FontWeight.BOLD, 18));
    ratingLabel.setTextFill(Color.RED);
    ratingLabel.setAlignment(Pos.CENTER);

     starButtons = new Button[NUM_STARS];
            for (int i = 0; i < NUM_STARS; i++) {
                Button starButton = new Button("",createImageView(STAR_EMPTY));
                int index = i; // Create a final copy of the index for the event handler
                starButton.setOnAction(event -> rate(index));
                 starButton.setMinSize(STAR_SIZE, STAR_SIZE);
                 starButton.setBackground(null); // Set the background to null to make it transparent

                starButtons[i] = starButton;
            }
        HBox starsContainer = new HBox(5);
        starsContainer.getChildren().addAll(starButtons);
        starsContainer.setPadding(new Insets(10));
        starsContainer.setAlignment(Pos.CENTER);
        starsContainer.setTranslateX(200);
        starsContainer.setTranslateY(100);

        //Create feedback label
        Label feedbackLabel = new Label("FeedBack:");
        feedbackLabel.setFont(Font.font("Times new roman", FontWeight.BOLD, 20));

        //Create feedback text field
        TextField feedbackField = new TextField();
        feedbackField.setStyle("-fx-background-color: rgba(167, 75, 54, 0.5 ); -fx-background-radius: 10px; -fx-border-radius: 10px;");

        //text area
        TextArea textArea = new TextArea();
        textArea.setPrefColumnCount(15);
        textArea.setPrefRowCount(2);
        textArea.setLayoutX(200);
        textArea.setLayoutY(120);

        //Create feedback
        HBox feedback = new HBox();
        feedback.getChildren().addAll(feedbackLabel, textArea);
        feedback.setPadding(new Insets(10));
        feedback.setSpacing(10);
        feedback.setLayoutX(220);
        feedback.setLayoutY(200);

        Button submitButton = new Button("submit");
        submitButton.setLayoutX(360);
        submitButton.setLayoutY(285);
        submitButton.setStyle("-fx-background-color: #dc836f; -fx-background-radius: 15px;");
        submitButton.setTextFill(Color.WHITE);
        submitButton.setFont(Font.font(16));
        
        Pane paneRating = new Pane();
        paneRating.setBackground(new Background(bg));
        paneRating.getChildren().addAll(header,starsContainer,feedback,submitButton);
        Scene SceneRating=new Scene(paneRating, 800, 400);
        ratingButton_S2.setOnAction(e->{
          //Set root as scene
        stage.setScene(SceneRating);
        //Launch newWindow
       // stage.show();
        });
        
        submitButton.setOnAction(e->{
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        Transaction tx = session.beginTransaction();
        
        // Create a new Test
        FeedBack newfeedback = new FeedBack();
        newfeedback.setScore(point); // Set the score based on the label value
        newfeedback.setComments(textArea.getText());
        newfeedback.setDate(LocalDate.now());

        // Save the test to the database
        session.save(newfeedback);
        tx.commit();

        Rectangle successRect = new Rectangle(400, 50); // Adjust the dimensions as needed
        successRect.setFill(Color.web("#992725", 0.5)); // Use the specified color with transparency

        Text successText = new Text("The feedback send,Thank You");
        successText.setFill(Color.WHITE);
        successText.setFont(Font.font("Helvetica", FontWeight.BOLD, 20));

        StackPane successPane = new StackPane(successRect, successText);
        successPane.setAlignment(Pos.CENTER);

        BorderPane successBorderPane = new BorderPane();
        successBorderPane.setCenter(successPane);

        StackPane finalPane = new StackPane(paneRating, successBorderPane);

        Scene successScene = new Scene(finalPane, 800, 400);
        stage.setScene(successScene);
        stage.show();
        // Set up a timeline to remove the success message after a certain duration
        Duration displayDuration = Duration.seconds(2); // Adjust the duration as needed
        Timeline timeline = new Timeline(new KeyFrame(displayDuration, event -> {
            // Remove the success message
            stage.setScene(SceneRating); // Set the scene back to the login scene
            stage.show();
        }));
        timeline.play();
         } catch (Exception ex) {
        ex.printStackTrace();
        // Handle other exceptions
    }    
         }) ;
    //--------------********Scene LogOut******************--------------------  
        LogOutButton_S2.setOnAction(e->{
        stage.setScene(scene0);
        stage.show();
        });
        
    }//end of the start method

        private void rate(int rating) {
            for (int i = 0; i < NUM_STARS; i++) {
                if (i <= rating) {
                    point +=10;
                    starButtons[i].setGraphic(createImageView(STAR_FILLED));
                   System.out.println(" the point is "+ point);
                } else {
                    starButtons[i].setGraphic(createImageView(STAR_EMPTY));
                }
            }
        }

  private ImageView createImageView(Image image) {
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(STAR_SIZE);
        imageView.setFitHeight(STAR_SIZE);
        imageView.setPreserveRatio(true);
        return imageView;
    }

  private void increaseScore10() {
        score += 10; 
    }
   private void increaseScore2() {
        score += 2; 
    }
    private void increaseScore20() {
        score += 20; 
    }
    
    public static void main(String[] args) {
        launch();
    }

}